#!/usr/bin/env bash
# Reconstitue et vérifie l’AppImage. Ne lance jamais l’application.
set -euo pipefail

script_dir="$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd -P)"
app_name='Patrimoine_0.1.1_amd64.AppImage'
expected_sha256='6abd1f90a70baa001560787f46e5b10ced7e3fd364b428c99541c454b5d9c240'
expected_bytes='112196088'
target="$script_dir/$app_name"
tmp=''

cleanup() {
  if [[ -n "$tmp" && -e "$tmp" ]]; then
    rm -f -- "$tmp"
  fi
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM

fail() {
  printf 'Erreur : %s\n' "$*" >&2
  exit 1
}

command -v sha256sum >/dev/null 2>&1 || fail 'La commande sha256sum est nécessaire (paquet coreutils sous Debian).'

verify_file() {
  local file="$1" actual_sha256 actual_bytes
  [[ -f "$file" && ! -L "$file" ]] || return 1
  actual_bytes="$(wc -c < "$file")" || return 1
  [[ "$actual_bytes" -eq "$expected_bytes" ]] || return 1
  actual_sha256="$(sha256sum -- "$file")" || return 1
  actual_sha256="${actual_sha256%% *}"
  [[ "$actual_sha256" == "$expected_sha256" ]]
}

show_launch() {
  printf '\nApplication pour Linux Debian 13 x86_64 (amd64).\n'
  printf 'Pour la lancer manuellement :\n'
  printf '  cd -- %q\n' "$script_dir"
  printf '  ./%s\n' "$app_name"
  printf '\nAucune application n’a été lancée par ce script.\n'
}

if [[ -e "$target" || -L "$target" ]]; then
  if verify_file "$target"; then
    printf 'Le fichier existant est complet et son SHA-256 est correct. Il est conservé sans modification.\n'
    show_launch
    exit 0
  fi
  fail "Le fichier $app_name existe déjà et ne correspond pas à la version attendue. Aucun écrasement effectué. Déplacez-le avant de recommencer."
fi

parts=()
for number in 01 02 03 04 05 06; do
  part="$script_dir/AppImage.part$number"
  [[ -f "$part" && ! -L "$part" && -r "$part" ]] || fail "Morceau absent ou illisible : AppImage.part$number. Extrayez les six ZIP dans le même dossier parent, puis recommencez."
  parts+=("$part")
done

tmp="$(mktemp -- "$script_dir/.${app_name}.reconstitution.XXXXXX")" || fail 'Impossible de créer le fichier temporaire.'
printf 'Reconstitution des six morceaux…\n'
cat -- "${parts[@]}" > "$tmp" || fail 'Échec de la reconstitution ; vérifiez l’espace disque disponible.'
verify_file "$tmp" || fail 'La taille ou le SHA-256 est incorrect. Les morceaux sont incomplets ou endommagés ; téléchargez-les à nouveau.'
chmod 0755 -- "$tmp"

# -n évite tout écrasement, y compris si un fichier apparaît pendant l’opération.
# -T interdit de déplacer le fichier à l’intérieur d’un répertoire existant.
mv -n -T -- "$tmp" "$target" || fail 'Impossible de publier le fichier reconstitué.'
if [[ -e "$tmp" ]]; then
  if verify_file "$target"; then
    printf 'Un fichier identique existe déjà. Il est conservé sans modification.\n'
    show_launch
    exit 0
  fi
  fail 'Un autre fichier est apparu à la destination. Aucun écrasement effectué.'
fi
tmp=''
printf 'Reconstitution terminée : %s\n' "$app_name"
printf 'Taille : %s octets. SHA-256 vérifié :\n%s\n' "$expected_bytes" "$expected_sha256"
printf 'Droits du fichier : 755 (exécutable).\n'
show_launch
