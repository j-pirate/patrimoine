#!/usr/bin/env python3
"""Apply the full qualification's exact proof to the completed pilot targets."""
import json
from pathlib import Path
import runpy
import sys

base = Path(__file__).resolve().parent
baseline_path = base / 'source-before-session.json'
baseline = json.loads(baseline_path.read_text())
scope = runpy.run_path(str(base.parent / 'performance-full' / 'verify_roundtrips.py'))
main = scope['main']
main.__globals__['BASE'] = base
current_sidecars = scope['fingerprint'](base / 'vault')['sidecars']
main.__globals__['SOURCE_CAPTURE'] = {
    'baseline_file': str(baseline_path),
    'generation_id': baseline['generation_id'],
    'size_bytes': baseline['database_bytes'],
    'database_sha256': baseline['database_sha256'],
    'sidecars': current_sidecars,
    'sidecars_capture_scope': 'Captured at exact verification only; pre-session baseline '
                              'contains main database SHA-256, size and generation. '
                              'The verifier requires WAL absent or empty.',
}
if __name__ == '__main__':
    sys.exit(main())
