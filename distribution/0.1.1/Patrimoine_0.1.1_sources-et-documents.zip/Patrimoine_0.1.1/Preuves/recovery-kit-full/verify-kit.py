import hashlib,json,sqlite3,subprocess,sys,tempfile,time,zipfile
from pathlib import Path
start=time.monotonic(); out=Path('/artifacts'); kit=out/'kit'; kit.mkdir()
with zipfile.ZipFile('/app/kit.zip') as archive: archive.extractall(kit)
manifest=json.loads((kit/'CONTENU.json').read_text())
for item in manifest['files']:
    raw=(kit/item['path']).read_bytes(); assert len(raw)==item['size_bytes'] and hashlib.sha256(raw).hexdigest()==item['sha256']
with (out/'cli-result.json').open('w') as stdout, (out/'cli-stderr.txt').open('w') as stderr:
    run=subprocess.run([sys.executable,str(kit/'scripts/recover-csv.py'),'/app/csv.zip','--output',str(out/'recovered.sqlite3'),'--documents-dir',str(out/'documents')],stdout=stdout,stderr=stderr)
assert run.returncode==0,(out/'cli-stderr.txt').read_text()
cli=json.loads((out/'cli-result.json').read_text()); assert cli['knowledge_sequence']==2 and cli['table_count']==62 and cli['row_count']==773124 and cli['blob_count']==10000
with tempfile.TemporaryDirectory() as temporary, zipfile.ZipFile('/app/backup.zip') as backup:
    source=Path(temporary)/'source.sqlite3'
    with backup.open('data/patrimoine.sqlite3') as original, source.open('wb') as target:
        for block in iter(lambda:original.read(1024*1024),b''):target.write(block)
    c=sqlite3.connect('file:'+str(source)+'?mode=ro',uri=True); r=sqlite3.connect('file:'+str(out/'recovered.sqlite3')+'?mode=ro',uri=True)
    names=[row[0] for row in c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
    hashes={}; count=0
    for table in names:
        info=c.execute(f'PRAGMA table_info("{table}")').fetchall(); assert info==r.execute(f'PRAGMA table_info("{table}")').fetchall()
        keys=[row[1] for row in sorted(info,key=lambda x:x[5]) if row[5]]
        query=f'SELECT * FROM "{table}" ORDER BY '+','.join('"'+key+'"' for key in keys)
        def fingerprint(connection):
            digest=hashlib.sha256(); n=0
            for row in connection.execute(query):
                digest.update((json.dumps(list(row),ensure_ascii=False,separators=(',',':'))+'\n').encode());n+=1
            return n,digest.hexdigest()
        expected=fingerprint(c); assert expected==fingerprint(r),table
        count+=expected[0]; hashes[table]=expected[1]
    assert len(names)==62 and count==773124
    m=json.loads(backup.read('manifest.json')); originals=[x for x in m['files'] if x['path'].startswith('documents/')]
    for item in originals:
        raw=backup.read(item['path']); restored=out/'documents'/item['path'].removeprefix('documents/')
        assert restored.read_bytes()==raw and hashlib.sha256(raw).hexdigest()==item['sha256']
    assert len(originals)==10000 and len([p for p in (out/'documents').rglob('*') if p.is_file()])==10000
proof={'status':'passed','method':'Only extracted recovery kit, standard Python/SQLite, network disabled; independent typed row digests against binary backup','application_version':manifest['application_version'],'source_knowledge_sequence':2,'tables':len(names),'typed_rows':count,'originals':len(originals),'elapsed_seconds':time.monotonic()-start,'financial_engine_executed':False,'table_hashes':hashes}
(out/'recovery-kit-result.json').write_text(json.dumps(proof,indent=2)+'\n'); print({k:v for k,v in proof.items() if k!='table_hashes'})
