#!/usr/bin/env python3
"""Resume missing full-fixture cases after the local-schema CSV import-order fix.

The ordinary dashboard still has a 120-second watchdog. Archive services repeat
full validation, so use an explicit 600-second archival budget. This helper only
writes proof files beside the existing synthetic fixture; it never edits data.
"""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
spec = importlib.util.spec_from_file_location('qualification', ROOT/'scripts/qualify-performance.py')
qualification = importlib.util.module_from_spec(spec)
spec.loader.exec_module(qualification)
original_stage = qualification.session_stage
ARCHIVES = {'backup','csv_export','csv_inspect','backup_roundtrip','csv_roundtrip'}

def bounded_stage(process, operation, artifacts, timeout, stem):
    budget = 600 if operation in ARCHIVES else 120
    return original_stage(process, operation, artifacts, budget, 'resumed-'+stem)

qualification.session_stage = bounded_stage
report = BASE/'performance.json'
metadata = json.loads((BASE/'performance-before-csv-import-order.json').read_text())
binary = Path(metadata['binary'])
old_hash = metadata['binary_sha256']
new_hash = hashlib.sha256(binary.read_bytes()).hexdigest()
for row in metadata['measurements'] + metadata['session_startups']:
    row.setdefault('binary_sha256', old_hash)
metadata['binary_versions'] = [{'sha256':old_hash,'scope':'original reads, exports and pre-fix timeout proofs'}, {'sha256':new_hash,'scope':'post-fix CSV inspection/reconstruction, backup reconstruction and dashboard'}]
metadata['current_binary_sha256'] = new_hash
metadata['csv_import_order_fix'] = 'Only INSERT traversal follows approved local foreign-key dependencies; no schema, format, foreign-key disabling or validation change.'
AFTER = BASE/'after-csv-import-order'
AFTER.mkdir(mode=0o700,exist_ok=True)
metadata['resumed_at'] = datetime.now(timezone.utc).isoformat()
metadata['archival_timeout_seconds'] = 600
metadata['ordinary_watchdog_seconds'] = 120
metadata['resume_reason'] = 'Original full CSV inspection reached 600 seconds while importing child tables before parents; preserved before-fix proof. Only missing operations resume after local-schema dependency insertion order fix; original ordinary timings and exports retained.'
metadata['reproduction_helper'] = str(Path(__file__).resolve())
for kind,result in qualification.measure_session(binary, BASE/'vault', ['csv_inspect','backup_roundtrip','csv_roundtrip','dashboard'], AFTER, 120):
    result['measurement_attempt'] = 'after-csv-import-order'
    result['binary_sha256'] = new_hash
    if kind == 'startup': metadata['session_startups'].append(result)
    elif kind == 'measurement': metadata['measurements'].append(result)
    else: metadata['remaining_operations_skipped'] = result
    metadata['hardware']['last_load_average'] = qualification.os.getloadavg()
    final = {row['operation']: row for row in metadata['measurements']}
    metadata['final_operation_status'] = {op: row['status'] for op,row in final.items()}
    metadata['final_passed_operations'] = sum(row['status']=='passed' for row in final.values())
    report.write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n')
metadata['completed_at'] = datetime.now(timezone.utc).isoformat()
report.write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n')
sys.exit(0 if all(row=='passed' for row in metadata['final_operation_status'].values()) else 1)
