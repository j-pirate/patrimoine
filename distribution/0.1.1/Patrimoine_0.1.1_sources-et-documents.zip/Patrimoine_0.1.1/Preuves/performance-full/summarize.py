#!/usr/bin/env python3
"""Compact, reproducible index of the completed synthetic volume proofs."""
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent
report = json.loads((BASE/'performance.json').read_text())
exact = json.loads((BASE/'roundtrip-exact.json').read_text())
assert report.get('completed_at') and exact['status']=='passed'
report['driver_source_unchanged_scope'] = 'Per-call source_unchanged checks generation and mutation sequence. The separate exact proof verifies all source records, types, identifiers, history and blobs; it explicitly records changed SQLite journal header bytes.'
report['source_preservation_verification'] = {
 'logical_data_preserved':exact['source_logical_data_preserved_since_capture'],
 'raw_database_bytes_unchanged':exact['source_raw_bytes_unchanged_since_capture'],
 'all_bytes_from_offset_100_to_eof_unchanged':exact['source_all_bytes_from_offset_100_to_eof_unchanged'],
 'header_change_witness':exact.get('source_header_change_witness'),
 'proof':'roundtrip-exact.json'
}
(BASE/'performance.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n')
final = {row['operation']:row for row in report['measurements']}
ordinary = [row for row in final.values() if row['ordinary_consultation_target_seconds'] is not None]
summary = {
 'status':'completed_with_unmet_performance_targets',
 'fixture':{key:report['fixture'][key] for key in ['profile','people','companies','assets','movements','documents','unique_blobs','document_bytes_each','change_sets','rows','seed_semantics']},
 'hardware':report['hardware'],
 'final_correctness_cases':{'total':len(final),'passed':sum(row['status']=='passed' for row in final.values()),'timeouts':[name for name,row in final.items() if row['status']=='timeout']},
 'ordinary_target':{'seconds':2,'cases':len(ordinary),'met':sum(row.get('provisional_target_met',False) for row in ordinary)},
 'measurements':[{key:row[key] for key in ['operation','status','timeout_seconds','wall_seconds','sampled_peak_rss_kib','binary_sha256','ordinary_consultation_target_seconds','provisional_target_met'] if key in row} | {'service_seconds':row.get('open_seconds') if row['operation']=='open' else row.get('operation_seconds')} for row in final.values()],
 'exact_roundtrips':[{key:row[key] for key in ['kind','status','knowledge_sequence','all_62_tables_equal','all_source_identifiers_preserved','documents','database_arithmetic_oracle']} for row in exact['roundtrips']],
 'source_logical_data_preserved':exact['source_logical_data_preserved_since_capture'],
 'source_raw_database_bytes_unchanged':exact['source_raw_bytes_unchanged_since_capture'],
 'source_header_change_witness':exact.get('source_header_change_witness'),
 'source_fingerprint':exact['source_after_verification'],
 'archive_capacity':json.loads((BASE/'archive-capacity.json').read_text()),
 'binary_versions':report['binary_versions'],
 'limits':[
  'Synthetic bulk fixture has two source change sets, not 100000 sequential committed mutations.',
  '10000 distinct original blobs are 128 bytes each; file count does not represent large PDF or video bytes.',
  'One sample per operation; shared validated processes retain allocator/cache state; disk caches were not cleared.',
  'Repository tests/builds ran concurrently; load averages and cgroup limits are recorded; no GUI latency claim.',
  'VmHWM is cumulative when Linux peak reset is denied; sampled RSS covers each operation window.',
  'Archive calls use an explicit 600 s budget; the ordinary/dashboard watchdog is 120 s. The initial 120 s backup and pre-fix 600 s CSV failures remain in raw reports.',
 ],
 'proofs':{'measurements':'performance.json','typed_rows_originals_and_decimal_oracles':'roundtrip-exact.json','archive_limits':'archive-capacity.json','pre_fix_csv_timeout':'performance-before-csv-import-order.json','quadratic_fk_experiment':'csv-fk-order-repro.json'}
}
(BASE/'performance-summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':summary['status'],'correctness_cases':summary['final_correctness_cases'],'ordinary_target':summary['ordinary_target'],'source_logical_data_preserved':summary['source_logical_data_preserved'],'source_raw_database_bytes_unchanged':summary['source_raw_database_bytes_unchanged']}))
