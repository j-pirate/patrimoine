#!/usr/bin/env python3
"""Read-only, exact post-check of the isolated full-fixture round trips.

Run after both release-driver target vaults exist. Only roundtrip-exact.json is
written. SQL values are hashed with storage-class tags and byte lengths; every
column participates in deterministic ordering. CSV's explicit import change and
audit event are checked separately, then excluded from source-row comparison.
"""
from __future__ import annotations

from collections import Counter
from datetime import datetime, timezone
from decimal import Decimal
import hashlib
import json
from pathlib import Path
import sqlite3
import struct
import sys
import tempfile
import time
import uuid
import zipfile

BASE = Path(__file__).resolve().parent
SOURCE_CAPTURE = {
    'captured_at': '2026-11-13T14:01:15.806523+00:00',
    'generation_id': '0d9d13b9-ef9f-46c4-82e1-781c6328ee37',
    'size_bytes': 215175168,
    'database_sha256': '85ed8bc08541fcabf788e280dcefb2bdd8ff2587f4dadc00e3ded2108ee75ffb',
    'sidecars': [],
}


def require(ok, message):
    if not ok:
        raise AssertionError(message)


def quoted(name):
    return '"' + name.replace('"', '""') + '"'


def active(root):
    generation = (root / 'CURRENT').read_text().strip()
    require(generation and '/' not in generation and generation not in ('.', '..'),
            f'Invalid generation in {root}')
    return generation, root / 'generations' / generation


def file_hash(path):
    with path.open('rb') as file:
        return hashlib.file_digest(file, 'sha256').hexdigest()


def fingerprint(root):
    generation, folder = active(root)
    path = folder / 'patrimoine.sqlite3'
    sidecars = []
    for extra in sorted(folder.glob('patrimoine.sqlite3-*')):
        allowed_sizes = {'patrimoine.sqlite3-wal': 0, 'patrimoine.sqlite3-shm': 32768}
        require(extra.name in allowed_sizes and not extra.is_symlink() and extra.is_file(),
                f'Unexpected SQLite sidecar: {extra}')
        size = extra.stat().st_size
        require(size == allowed_sizes[extra.name],
                f'Unexpected SQLite sidecar size or uncheckpointed WAL: {extra} ({size} bytes)')
        sidecars.append({'name': extra.name, 'size_bytes': size,
                         'sha256': file_hash(extra)})
    return {'generation_id': generation, 'size_bytes': path.stat().st_size,
            'database_sha256': file_hash(path), 'sidecars': sidecars}


def source_header_witness(root, current):
    """Prove a diagnosed header-only change without changing the real file.

    This does not make the raw-byte preservation assertion pass: the report
    explicitly records it as false. It proves every other original byte remains
    present by reconstructing the initial full-file SHA-256 in memory.
    """
    diagnostic_path = BASE / 'source-header-diagnosis.json'
    diagnostic = json.loads(diagnostic_path.read_text())
    witness = diagnostic['baseline_header_reconstruction']['witness']
    require(diagnostic['source_sha256'] == current['database_sha256'],
            'Header diagnostic does not describe the current source')
    reconstructed = bytes.fromhex(witness['header100hex'])
    require(len(reconstructed) == 100, 'Header witness must contain exactly 100 bytes')
    _, folder = active(root)
    with (folder / 'patrimoine.sqlite3').open('rb') as file:
        original = file.read(100)
        changes = [{'offset': i, 'current': a, 'baseline': b}
                   for i, (a, b) in enumerate(zip(original, reconstructed)) if a != b]
        allowed = {18, 19, *range(24, 28), *range(92, 100)}
        require(changes and all(change['offset'] in allowed for change in changes),
                'Header witness changes fields outside journal/counter/writer metadata')
        digest = hashlib.sha256(reconstructed)
        while chunk := file.read(1024 * 1024):
            digest.update(chunk)
    require(digest.hexdigest() == SOURCE_CAPTURE['database_sha256'],
            'Reconstructed full-file SHA-256 does not match the pre-session source')
    return {'status': 'cryptographically_verified_header_only_change',
            'diagnostic': str(diagnostic_path), 'changed_header_bytes': changes,
            'current_database_sha256': current['database_sha256'],
            'reconstructed_pre_session_database_sha256': digest.hexdigest(),
            'all_bytes_from_offset_100_to_eof_unchanged': True,
            'explanation': 'First real backup opens its source with db::connect, whose '
                'PRAGMA journal_mode=WAL changes DELETE journal header metadata and writer '
                'version. This changes the raw source file SHA-256. The original file was '
                'never edited by this verifier; only the 100-byte header was reconstructed '
                'in memory for the full-file SHA-256 witness.'}


def connect(root):
    _, folder = active(root)
    path = folder / 'patrimoine.sqlite3'
    wal = folder / 'patrimoine.sqlite3-wal'
    require(not wal.exists() or wal.stat().st_size == 0,
            f'Close and checkpoint the finished benchmark vault before verification: {root}')
    # The driver has exited and the complete snapshot is in the main database.
    # immutable forbids SQLite from creating WAL/SHM files during this proof.
    connection = sqlite3.connect(path.as_uri() + '?mode=ro&immutable=1', uri=True)
    connection.execute('PRAGMA query_only=ON')
    connection.execute('PRAGMA trusted_schema=OFF')
    connection.execute('BEGIN')
    return connection, folder


def schema(connection):
    definitions = [list(row) for row in connection.execute(
        "SELECT type,name,tbl_name,sql FROM sqlite_master "
        "WHERE name NOT LIKE 'sqlite_%' ORDER BY type,name")]
    tables = [row[0] for row in connection.execute(
        "SELECT name FROM sqlite_master WHERE type='table' "
        "AND name NOT LIKE 'sqlite_%' ORDER BY name")]
    columns = {name: [list(row) for row in connection.execute(
        f'PRAGMA table_xinfo({quoted(name)})')] for name in tables}
    return {'definitions': definitions, 'tables': tables, 'columns': columns}


def encode(value):
    if value is None:
        return b'N', b''
    if isinstance(value, int):
        return b'I', str(value).encode('ascii')
    if isinstance(value, float):
        return b'R', struct.pack('>d', value)
    if isinstance(value, str):
        return b'T', value.encode('utf-8')
    if isinstance(value, bytes):
        return b'B', value
    raise AssertionError(f'Unsupported SQLite value type: {type(value)}')


def table_digest(connection, name, columns, where=''):
    # typeof + hex makes order sensitive to SQL storage type and embedded NULs.
    # SQLite's 26-digit formatting distinguishes representable REAL values too.
    ordering = []
    for column in columns:
        identifier = quoted(column[1])
        ordering += [f'typeof({identifier})',
                     f"CASE WHEN typeof({identifier})='real' "
                     f"THEN printf('%!.26g',{identifier}) ELSE hex({identifier}) END"]
    sql = f'SELECT * FROM {quoted(name)} {where} ORDER BY ' + ','.join(ordering)
    digest = hashlib.sha256()
    count = 0
    types = Counter()
    for row in connection.execute(sql):
        digest.update(b'row\x00')
        for value in row:
            tag, data = encode(value)
            digest.update(tag)
            digest.update(len(data).to_bytes(8, 'big'))
            digest.update(data)
            types[tag.decode('ascii')] += 1
        count += 1
    return {'rows': count, 'typed_rows_sha256': digest.hexdigest(),
            'storage_classes': dict(sorted(types.items()))}


def document_digest(connection, folder, expected):
    digest = hashlib.sha256()
    count = total = 0
    for sha256, size, relative in connection.execute(
            'SELECT sha256,size_bytes,relative_path FROM document_blobs ORDER BY sha256'):
        path = folder / relative
        require(path.is_relative_to(folder) and path.resolve().is_relative_to(folder.resolve()),
                f'Blob path escapes generation: {relative}')
        require(path.is_file() and not path.is_symlink(), f'Missing regular blob {relative}')
        require(size == expected['document_bytes_each'], f'Unexpected blob size {relative}')
        require(path.stat().st_size == size and file_hash(path) == sha256,
                f'Blob content differs from metadata: {relative}')
        digest.update(sha256.encode('ascii'))
        digest.update(size.to_bytes(8, 'big'))
        digest.update(relative.encode('utf-8'))
        digest.update(b'\x00')
        count += 1
        total += size
    require(count == expected['unique_blobs'], 'Unique blob count differs from fixture')
    physical = [path for path in (folder / 'documents').rglob('*') if path.is_file()]
    require(len(physical) == count, 'Unexpected or missing physical document files')
    return {'blobs': count, 'bytes': total, 'all_blob_sha256_match': True,
            'metadata_and_bytes_sha256': digest.hexdigest()}


def csv_provenance(connection, source_sequence):
    added = list(connection.execute(
        'SELECT * FROM change_sets WHERE sequence>? ORDER BY sequence', (source_sequence,)))
    require(len(added) == 1 and added[0][1] == source_sequence + 1,
            'CSV must append exactly one import change set')
    change = added[0]
    require(change[3] == 'Réimportation CSV intégrale', 'Unexpected CSV provenance reason')
    events = list(connection.execute('SELECT * FROM audit_events WHERE change_set_id=?',
                                     (change[0],)))
    require(len(events) == 1 and events[0][3] is None and events[0][4] == 'csv_imported',
            'CSV must append exactly one csv_imported audit event with NULL revision')
    workspace = connection.execute(
        "SELECT value_text FROM app_settings WHERE key='workspace_id'").fetchone()[0]
    require(events[0][2] == workspace, 'CSV provenance must refer to source workspace')
    return {'change_sets_added': 1, 'audit_events_added': 1,
            'change_set': list(change), 'audit_event': list(events[0])}


def database_arithmetic_oracle(connection, expected):
    """Independent Decimal arithmetic over the fixture's dated revision heads.

    This directly checks preserved facts; application service report timings and
    their financial assertions remain separate evidence in performance.json.
    """
    latest = connection.execute('SELECT max(sequence) FROM change_sets').fetchone()[0]
    rates = {'EUR': Decimal('1'), 'USD': Decimal('0.8'), 'TND': Decimal('0.3')}
    known_head = ('JOIN revisions r ON r.id=v.revision_id '
                  'JOIN change_sets c ON c.id=r.change_set_id '
                  'WHERE c.sequence<=? AND r.is_void=0 AND NOT EXISTS '
                  '(SELECT 1 FROM revisions n JOIN change_sets nc ON nc.id=n.change_set_id '
                  'WHERE n.supersedes_revision_id=r.id AND nc.sequence<=?)')
    results = {}
    for label, knowledge in [('historical_k1', 1), ('current_k2', 2), ('latest', latest)]:
        account = list(connection.execute(
            'SELECT v.currency FROM treasury_accounts v ' + known_head + ' AND r.object_id=?',
            (knowledge, knowledge, expected['account_id'])))
        require(account == [('EUR',)], 'Arithmetic oracle requires exactly the preserved EUR account')
        bank_sql = ('SELECT e.amount FROM treasury_entries e '
                    'JOIN treasury_transactions v ON v.revision_id=e.transaction_revision_id ' +
                    known_head + ' AND e.account_id=?')
        bank = Decimal(0)
        movements = 0
        for (amount,) in connection.execute(bank_sql, (knowledge, knowledge, expected['account_id'])):
            require(isinstance(amount, str), 'Bank amount lost exact TEXT storage')
            bank += Decimal(amount)
            movements += 1
        require(movements == expected['movements'], 'Arithmetic oracle movement count differs')
        require(bank == Decimal(expected['bank_balance']), 'Arithmetic oracle bank balance differs')
        asset_values = Decimal(0)
        valuations = 0
        currencies = Counter()
        for amount, currency in connection.execute(
                'SELECT v.amount,v.currency FROM valuations v ' + known_head,
                (knowledge, knowledge)):
            require(isinstance(amount, str), 'Valuation lost exact TEXT storage')
            require(currency in rates, f'Unexpected arithmetic-oracle currency {currency}')
            asset_values += Decimal(amount) * rates[currency]
            valuations += 1
            currencies[currency] += 1
        require(valuations == expected['assets'] - 1, 'Arithmetic oracle valuation count differs')
        total = asset_values + bank
        expected_total = expected['historical_assets_eur' if knowledge == 1 else 'current_assets_eur']
        require(total == Decimal(expected_total), 'Arithmetic oracle financial total differs')
        results[label] = {'knowledge_sequence': knowledge, 'treasury_movements': movements,
                         'bank_balance_eur': format(bank, '.2f'), 'valuation_heads': valuations,
                         'valuation_currencies': dict(sorted(currencies.items())),
                         'valuations_eur': format(asset_values, '.2f'),
                         'assets_eur': format(total, '.2f'), 'matches_independent_fixture_oracle': True}
    return {'method': 'Database arithmetic oracle: Python Decimal sums of dated revision heads, '
                      'fixed independent fixture rates EUR=1, USD=0.8, TND=0.3, plus bank journal. '
                      'Application financial-service report assertions are separate evidence.',
            'rates': {key: str(value) for key, value in rates.items()}, 'results': results}


def deterministic_identifier_oracle(connection, expected):
    def identity(name):
        return str(uuid.uuid5(uuid.NAMESPACE_URL, 'patrimoine-performance-1/' + name))

    groups = {}
    for name, count, sql in [
            ('person', expected['people'], "SELECT id FROM entities WHERE kind='person'"),
            ('company', expected['companies'], "SELECT id FROM entities WHERE kind='company'"),
            ('asset', expected['assets'], 'SELECT id FROM assets'),
            ('document', expected['documents'], 'SELECT id FROM documents')]:
        wanted = {identity(f'object/{name}/{index}') for index in range(count)}
        actual = {row[0] for row in connection.execute(sql)}
        require(actual == wanted, f'Deterministic UUID5 identifiers differ for {name}')
        digest = hashlib.sha256('\n'.join(sorted(actual)).encode('ascii')).hexdigest()
        groups[name] = {'count': len(actual), 'sorted_ids_sha256': digest,
                        'matches_independent_uuid5_formula': True}
    owner = identity('object/person/0')
    account = identity('object/account')
    require(expected['owner_id'] == owner and expected['account_id'] == account,
            'Expected owner/account identifiers differ from independent UUID5 formula')
    accounts = {row[0] for row in connection.execute(
        'SELECT r.object_id FROM treasury_accounts a JOIN revisions r ON r.id=a.revision_id')}
    require(accounts == {account}, 'Preserved treasury account identifier differs')
    return {'namespace': 'UUID5 NAMESPACE_URL', 'prefix': 'patrimoine-performance-1/',
            'object_pattern': 'object/{person|company|asset|document}/{zero_based_index}',
            'groups': groups, 'owner_id': owner, 'account_id': account,
            'all_expected_identifiers_exact': True}


def canonical_backup_proof(source_tables, source_schema, expected):
    archive = BASE / 'benchmark-backup.zip'
    archive_hash = file_hash(archive)
    with zipfile.ZipFile(archive) as zipped:
        manifest = json.loads(zipped.read('manifest.json'))
        require(manifest['mutation_sequence'] == 2, 'Canonical backup must retain K=2')
        require(manifest['table_counts'] == expected['table_counts'],
                'Canonical backup manifest counts differ from fixture')
        entry = next(row for row in manifest['files'] if row['path'] == 'data/patrimoine.sqlite3')
        with tempfile.TemporaryDirectory(prefix='.exact-backup-', dir=BASE) as scratch:
            path = Path(scratch) / 'patrimoine.sqlite3'
            digest = hashlib.sha256()
            copied = 0
            with zipped.open(entry['path']) as incoming, path.open('xb') as output:
                while chunk := incoming.read(1024 * 1024):
                    output.write(chunk)
                    digest.update(chunk)
                    copied += len(chunk)
            require(copied == entry['size_bytes'] and digest.hexdigest() == entry['sha256'],
                    'Canonical SQLite bytes differ from immutable backup manifest SHA-256')
            connection = sqlite3.connect(path.as_uri() + '?mode=ro&immutable=1', uri=True)
            try:
                connection.execute('PRAGMA query_only=ON')
                connection.execute('PRAGMA trusted_schema=OFF')
                require(schema(connection) == source_schema, 'Canonical backup schema differs')
                tables = {}
                for name in source_schema['tables']:
                    result = table_digest(connection, name, source_schema['columns'][name])
                    require(result == source_tables[name], f'Canonical backup typed rows differ: {name}')
                    tables[name] = {**result, 'matches_source': True}
                identifiers = deterministic_identifier_oracle(connection, expected)
                money = database_arithmetic_oracle(connection, expected)
            finally:
                connection.close()
    require(file_hash(archive) == archive_hash, 'Backup archive changed during direct verification')
    return {'status': 'passed', 'archive': str(archive), 'archive_sha256': archive_hash,
            'archive_unchanged_during_verification': True,
            'canonical_database_size_bytes': copied, 'canonical_database_sha256': digest.hexdigest(),
            'matches_manifest_database_sha256': True, 'all_62_schemas_equal': True,
            'all_62_tables_equal': True, 'rows': sum(row['rows'] for row in tables.values()),
            'tables': tables, 'deterministic_identifier_oracle': identifiers,
            'database_arithmetic_oracle': money,
            'method': 'Canonical SQLite entry streamed directly from backup ZIP into a disposable '
                'proof copy; complete SHA-256 checked against manifest before immutable read-only '
                'schema and typed-row comparison. Source vault and archive never edited.'}


def main():
    started = time.monotonic()
    report = {'created_at': datetime.now(timezone.utc).isoformat(), 'status': 'error',
              'method': 'Read-only 62-table schema/count/typed-row comparison and every blob SHA-256; '
                        'CSV permits only one explicit import change and audit event',
              'source_capture_before_roundtrips': SOURCE_CAPTURE,
              'source_baseline_fields_compared': ['generation_id', 'size_bytes', 'database_sha256'],
              'cache_sidecar_lifecycle_caveat': 'Real opens of the WAL-mode source may create '
                  'an empty patrimoine.sqlite3-wal and a 32768-byte patrimoine.sqlite3-shm cache '
                  'after the initial capture. Only these standard sidecars are permitted; '
                  'nonempty WAL and other sidecars fail. Pre-session data preservation compares '
                  'the main database SHA-256, bytes and active generation. Verification itself '
                  'uses immutable read-only connections and requires exact before/after equality '
                  'including the permitted sidecars and their SHA-256 values.'}
    connections = []
    try:
        source_root = BASE / 'vault'
        expected = json.loads((source_root / 'expected.json').read_text())
        before = fingerprint(source_root)
        for key in ['generation_id', 'size_bytes']:
            require(before[key] == SOURCE_CAPTURE[key],
                    f'Source differs from the pre-roundtrip capture: {key}')
        raw_unchanged = before['database_sha256'] == SOURCE_CAPTURE['database_sha256']
        report['source_raw_bytes_unchanged_since_capture'] = raw_unchanged
        report['raw_database_bytes_unchanged'] = raw_unchanged
        if not raw_unchanged:
            report['source_header_change_witness'] = source_header_witness(source_root, before)
            report['source_preservation_status'] = 'Original data bytes preserved; SQLite journal header changed'
        else:
            report['source_preservation_status'] = 'Main database bytes and generation unchanged'
        report['source_before_verification'] = before
        source, source_folder = connect(source_root)
        connections.append(source)
        source_schema = schema(source)
        require(len(source_schema['tables']) == 62, 'Fixture must contain all 62 tables')
        require(set(source_schema['tables']) == set(expected['table_counts']),
                'Fixture table names differ from expected.json')
        source_sequence = source.execute('SELECT max(sequence) FROM change_sets').fetchone()[0]
        require(source_sequence == expected['change_sets'] == 2, 'Source must remain at K=2')
        source_tables = {}
        for name in source_schema['tables']:
            result = table_digest(source, name, source_schema['columns'][name])
            require(result['rows'] == expected['table_counts'][name],
                    f'Source row count differs from fixture: {name}')
            source_tables[name] = result
        source_documents = document_digest(source, source_folder, expected)
        report['source'] = {'root': str(source_root), 'knowledge_sequence': source_sequence,
                            'tables': source_tables, 'schema': source_schema,
                            'rows': sum(row['rows'] for row in source_tables.values()),
                            'documents': source_documents,
                            'deterministic_identifier_oracle':
                                deterministic_identifier_oracle(source, expected),
                            'database_arithmetic_oracle': database_arithmetic_oracle(source, expected)}
        report['canonical_backup_direct_verification'] = canonical_backup_proof(
            source_tables, source_schema, expected)
        report['roundtrips'] = []
        for kind, name in [('backup', 'benchmark-backup-restored'),
                           ('csv', 'benchmark-csv-restored')]:
            target_root = BASE / name
            target, folder = connect(target_root)
            connections.append(target)
            target_schema = schema(target)
            require(target_schema == source_schema, f'{kind}: schema differs from source')
            sequence = target.execute('SELECT max(sequence) FROM change_sets').fetchone()[0]
            require(sequence == source_sequence + (kind == 'csv'),
                    f'{kind}: restored knowledge sequence differs')
            provenance = csv_provenance(target, source_sequence) if kind == 'csv' else None
            comparisons = {}
            for table in source_schema['tables']:
                where = ''
                extra = 0
                if kind == 'csv' and table == 'change_sets':
                    where = f'WHERE sequence <= {source_sequence}'
                    extra = 1
                if kind == 'csv' and table == 'audit_events':
                    where = ('WHERE change_set_id IN '
                             f'(SELECT id FROM change_sets WHERE sequence <= {source_sequence})')
                    extra = 1
                full_count = target.execute(f'SELECT count(*) FROM {quoted(table)}').fetchone()[0]
                require(full_count == source_tables[table]['rows'] + extra,
                        f'{kind}: full row count differs for {table}')
                result = table_digest(target, table, source_schema['columns'][table], where)
                require(result == source_tables[table],
                        f'{kind}: typed row content differs for {table}')
                comparisons[table] = {**result, 'full_rows': full_count, 'matches_source': True}
            documents = document_digest(target, folder, expected)
            require(documents == source_documents, f'{kind}: documentary originals differ')
            report['roundtrips'].append({'kind': kind, 'status': 'passed',
                'root': str(target_root), 'generation_id': active(target_root)[0],
                'knowledge_sequence': sequence, 'schemas_equal': True,
                'all_62_tables_equal': True, 'tables': comparisons,
                'all_source_identifiers_preserved': True,
                'identifier_preservation_evidence': 'Every source column in every row of all '
                    '62 tables has the same typed-row digest, including object, revision, '
                    'change-set, audit, account and document IDs and all foreign-key links. '
                    'Only the separately checked CSV import provenance creates two new rows.',
                'csv_provenance': provenance, 'documents': documents,
                'deterministic_identifier_oracle': deterministic_identifier_oracle(target, expected),
                'database_arithmetic_oracle': database_arithmetic_oracle(target, expected)})
        after = fingerprint(source_root)
        require(before == after, 'Source changed during exact verification')
        report['source_after_verification'] = after
        report['source_unchanged_since_capture'] = raw_unchanged
        report['source_logical_data_preserved_since_capture'] = True
        report['source_all_bytes_from_offset_100_to_eof_unchanged'] = True
        report['source_unchanged_during_verification'] = True
        report['source_unchanged_scope'] = ('All source records, identifiers, documentary originals, '
            'active generation and file size are preserved. The raw main-file SHA-256 changed '
            'only if source_header_change_witness explicitly proves and describes it. Exact '
            'before/after verification equality includes the main file and permitted sidecars.')
        report['status'] = 'passed'
    except Exception as error:
        report['error'] = {'type': type(error).__name__, 'message': str(error)}
    finally:
        for connection in connections:
            connection.close()
        report['wall_seconds'] = time.monotonic() - started
        (BASE / 'roundtrip-exact.json').write_text(
            json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'status': report['status'], 'wall_seconds': report['wall_seconds'],
                      'error': report.get('error'),
                      'source_raw_bytes_unchanged_since_capture':
                          report.get('source_raw_bytes_unchanged_since_capture'),
                      'source_logical_data_preserved_since_capture':
                          report.get('source_logical_data_preserved_since_capture'),
                      'report': str(BASE / 'roundtrip-exact.json')}))
    return 0 if report['status'] == 'passed' else 1


if __name__ == '__main__':
    sys.exit(main())
