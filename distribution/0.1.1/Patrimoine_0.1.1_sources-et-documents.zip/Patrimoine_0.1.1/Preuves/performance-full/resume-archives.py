#!/usr/bin/env python3
"""Resume preserved full-fixture proof with a separate bounded archive budget.

The ordinary dashboard still has a 120-second watchdog. Archive services repeat
full validation, so use an explicit 600-second archival budget. This helper only
writes proof files beside the existing synthetic fixture; it never edits data.
"""
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
spec = importlib.util.spec_from_file_location('qualification', ROOT/'scripts/qualify-performance.py')
qualification = importlib.util.module_from_spec(spec)
spec.loader.exec_module(qualification)
original_stage = qualification.session_stage
ARCHIVES = {'backup','csv_export','csv_inspect','backup_roundtrip','csv_roundtrip'}

def bounded_stage(process, operation, artifacts, timeout, stem):
    budget = 600 if operation in ARCHIVES else 120
    return original_stage(process, operation, artifacts, budget, 'resumed-'+stem)

qualification.session_stage = bounded_stage
report = BASE/'performance.json'
metadata = json.loads((BASE/'performance.json.120s-initial').read_text())
binary = Path(metadata['binary'])
assert hashlib.sha256(binary.read_bytes()).hexdigest() == metadata['binary_sha256']
metadata['resumed_at'] = datetime.now(timezone.utc).isoformat()
metadata['archival_timeout_seconds'] = 600
metadata['ordinary_watchdog_seconds'] = 120
metadata['resume_reason'] = 'Initial backup reached 120-second watchdog. Repeated complete archival validation uses separate 600-second budget. Initial timeout retained; next unmeasured CSV export was interrupted and excluded.'
metadata['reproduction_helper'] = str(Path(__file__).resolve())
for kind,result in qualification.measure_session(binary, BASE/'vault', ['backup','csv_export','csv_inspect','backup_roundtrip','csv_roundtrip','dashboard'], BASE, 120):
    result['measurement_attempt'] = 'archival-budget-resume'
    if kind == 'startup': metadata['session_startups'].append(result)
    elif kind == 'measurement': metadata['measurements'].append(result)
    else: metadata['remaining_operations_skipped'] = result
    metadata['hardware']['last_load_average'] = qualification.os.getloadavg()
    final = {row['operation']: row for row in metadata['measurements']}
    metadata['final_operation_status'] = {op: row['status'] for op,row in final.items()}
    metadata['final_passed_operations'] = sum(row['status']=='passed' for row in final.values())
    report.write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n')
metadata['completed_at'] = datetime.now(timezone.utc).isoformat()
report.write_text(json.dumps(metadata,ensure_ascii=False,indent=2)+'\n')
sys.exit(0 if all(row=='passed' for row in metadata['final_operation_status'].values()) else 1)
