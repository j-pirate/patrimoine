#!/usr/bin/env python3
"""Reproduce deferred-FK CSV import cost using official schema in memory only.

The full fixture is opened immutable/read-only solely to obtain its approved
four-table schema and indexes. Synthetic rows are inserted into fresh :memory:
databases with foreign_keys=ON and defer_foreign_keys=ON. Both orders finish a
foreign_key_check and commit. Only the adjacent JSON report is written.
"""
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import sqlite3
import time

BASE = Path(__file__).resolve().parent
TABLES = ['objects', 'change_sets', 'revisions', 'audit_events']
CHILD_FIRST = ['audit_events', 'change_sets', 'objects', 'revisions']
PARENT_FIRST = ['change_sets', 'objects', 'revisions', 'audit_events']


def main():
    root = BASE / 'vault'
    generation = (root / 'CURRENT').read_text().strip()
    database = root / 'generations' / generation / 'patrimoine.sqlite3'
    source = sqlite3.connect(database.as_uri() + '?mode=ro&immutable=1', uri=True)
    definitions = [source.execute(
        "SELECT sql FROM sqlite_master WHERE type='table' AND name=?", (name,)
    ).fetchone()[0] for name in TABLES]
    indexes = [row[0] for row in source.execute(
        "SELECT sql FROM sqlite_master WHERE type='index' AND sql IS NOT NULL "
        "AND tbl_name IN ('objects','change_sets','revisions','audit_events') ORDER BY name")]
    actual_rows = source.execute('SELECT count(*) FROM audit_events').fetchone()[0]
    actual_revisions = source.execute('SELECT count(*) FROM revisions').fetchone()[0]
    source.close()
    report = {
        'created_at': datetime.now(timezone.utc).isoformat(),
        'sqlite_python': sqlite3.sqlite_version,
        'source_generation': generation,
        'source_access': 'immutable read-only schema and counts only',
        'workload': 'Fresh in-memory databases; synthetic rows; official four-table schema '
                    'and indexes; foreign keys enabled/deferred; final foreign_key_check and commit',
        'initial_load_average': os.getloadavg(),
        'table_names': TABLES, 'official_table_definitions': definitions,
        'official_index_definitions': indexes,
        'children_first_order': CHILD_FIRST, 'parents_first_order': PARENT_FIRST,
        'full_fixture_audit_rows': actual_rows,
        'full_fixture_revision_rows': actual_revisions,
        'potential_audit_revision_comparisons': actual_rows * actual_revisions,
        'measurements': [],
    }
    for count in [1000, 2000, 4000]:
        for mode, order in [('children_first', CHILD_FIRST), ('parents_first', PARENT_FIRST)]:
            connection = sqlite3.connect(':memory:')
            connection.execute('PRAGMA foreign_keys=ON')
            for sql in definitions + indexes:
                connection.execute(sql)
            rows = {
                'objects': [(f'o-{i}', 'asset', 'stamp') for i in range(count)],
                'change_sets': [('c', 1, 'stamp', 'r', 'cmd')],
                'revisions': [(f'r-{i}', f'o-{i}', 'c', 'stamp', None, 0, 'reason')
                              for i in range(count)],
                'audit_events': [(f'a-{i}', 'c', f'o-{i}', f'r-{i}', 'e', 'reason')
                                 for i in range(count)],
            }
            started = time.monotonic()
            connection.execute('BEGIN')
            connection.execute('PRAGMA defer_foreign_keys=ON')
            for name in order:
                placeholders = ','.join('?' for _ in rows[name][0])
                connection.executemany(f'INSERT INTO {name} VALUES({placeholders})', rows[name])
            errors = connection.execute('PRAGMA foreign_key_check').fetchall()
            if errors:
                raise AssertionError(f'Foreign key check failed: {errors}')
            connection.commit()
            seconds = time.monotonic() - started
            counts = {name: connection.execute(f'SELECT count(*) FROM {name}').fetchone()[0]
                      for name in TABLES}
            if counts != {'objects': count, 'change_sets': 1,
                          'revisions': count, 'audit_events': count}:
                raise AssertionError(f'Unexpected row counts: {counts}')
            report['measurements'].append({'rows_per_large_table': count, 'order': mode,
                                           'seconds': seconds, 'foreign_key_check': 'passed',
                                           'committed_row_counts': counts})
            connection.close()
    report['last_load_average'] = os.getloadavg()
    report['status'] = 'passed'
    output = BASE / 'csv-fk-order-repro.json'
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
    print(json.dumps({'status': 'passed', 'report': str(output),
                      'measurements': report['measurements']}))


if __name__ == '__main__':
    main()
