import hashlib
import json
import sqlite3
import sys
import zipfile
from collections import defaultdict
from fractions import Fraction as F
from pathlib import Path

root = Path('/workspace/patrimoine')
artifacts = Path(sys.argv[1])

def require(condition, message):
    if not condition:
        raise AssertionError(message)

def current(c, table, cutoff=None):
    cutoff = cutoff if cutoff is not None else c.execute('SELECT max(sequence) FROM change_sets').fetchone()[0]
    return [dict(r) for r in c.execute(f'''SELECT v.*,r.object_id,r.change_set_id AS _change_set_id,cs.sequence AS _sequence
        FROM "{table}" v JOIN revisions r ON r.id=v.revision_id JOIN change_sets cs ON cs.id=r.change_set_id
        WHERE cs.sequence<=? AND r.is_void=0 AND NOT EXISTS(
          SELECT 1 FROM revisions n JOIN change_sets ns ON ns.id=n.change_set_id
          WHERE n.object_id=r.object_id AND ns.sequence<=? AND ns.sequence>cs.sequence)''',(cutoff,cutoff))]

def inspect(path):
    with zipfile.ZipFile(path) as z:
        require(z.testzip() is None, 'Corrupt ZIP')
        manifest=json.loads(z.read('manifest.json'))
        require(manifest['schema_version']==6 and manifest['format_version']==1,'Unexpected version')
        for entry in manifest['files']:
            raw=z.read(entry['path'])
            require(len(raw)==entry['size_bytes'] and hashlib.sha256(raw).hexdigest()==entry['sha256'],'Manifest size or hash mismatch')
        c=sqlite3.connect(':memory:');c.row_factory=sqlite3.Row;c.deserialize(z.read('data/patrimoine.sqlite3'))
    require(c.execute('pragma user_version').fetchone()[0]==6,'Wrong SQLite schema')
    require(c.execute('pragma integrity_check').fetchone()[0]=='ok','Integrity check')
    require(not c.execute('pragma foreign_key_check').fetchall(),'Foreign key violations')
    tables=sorted(r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"))
    counts={table:c.execute(f'SELECT count(*) FROM "{table}"').fetchone()[0] for table in tables}
    require(counts==manifest['table_counts'],'Manifest table counts')
    for row in c.execute('SELECT version,checksum FROM schema_migrations ORDER BY version'):
        sql=next((root/'crates/infrastructure/migrations').glob(f'{row[0]:04d}_*.sql'))
        require(hashlib.sha256(sql.read_bytes()).hexdigest()==row[1],f'Migration checksum {row[0]}')
    transactions={r['revision_id']:r for r in current(c,'treasury_transactions')}
    entries={(r['transaction_revision_id'],r['line_id']):dict(r) for r in c.execute('SELECT * FROM treasury_entries') if r['transaction_revision_id'] in transactions}
    accounts=current(c,'treasury_accounts');balances=defaultdict(F)
    for row in entries.values():balances[row['account_id']]+=F(row['amount'])
    named={r['reference']:balances[r['object_id']] for r in accounts if r['kind']=='bank'}
    require(named['TEST-A']==-42 and named['TEST-B']==2430 and named['CO-TEST']==700,'Bank oracle')
    cash=next(r for r in accounts if r['kind']=='cash' and r['currency']=='TND')
    require(balances[cash['object_id']]==330,'Cash oracle')
    debt=next(r for r in current(c,'debt_contracts') if r['name']=='Prêt bancaire du test')
    debt_moves=[m for m in current(c,'debt_movements') if m['debt_id']==debt['object_id']]
    require(sum(F(m['principal_change']) for m in debt_moves)==99000 and sum(F(m['interest_paid']) for m in debt_moves)==200 and sum(F(m['fees_paid']) for m in debt_moves)==10,'Loan oracle')
    deposits=current(c,'deposit_movements');require(sum(F(m['amount']) for m in deposits)==1200,'Deposit obligation')
    dues=current(c,'rent_dues');january=next(d for d in dues if d['period_start']=='2023-01-01')
    allocations=current(c,'rent_allocations')
    outstanding=F(january['rent'])-sum(F(a['amount']) for a in allocations if a['due_id']==january['object_id'] and a['component']=='rent')+sum(F(d['amount']) for d in deposits if d['kind']=='applied_to_due' and d['due_id']==january['object_id'])
    require(outstanding==700,'January claim')
    payments=current(c,'rent_payments');require(len(payments)==3 and sum(F(p['amount']) for p in payments)==1000,'No deposit as fake rent')
    lot=current(c,'metal_lots')[0];moves=sorted(current(c,'metal_movements'),key=lambda r:(r['effective_on'],r['object_id']))
    require(sum(F(m['quantity_change']) for m in moves)==1,'Remaining metal quantity')
    opening=next(m for m in moves if m['kind']=='opening');sale=next(m for m in moves if m['kind']=='sale')
    opening_cost=F(opening['cost_amount']);allocated=opening_cost*-F(sale['quantity_change'])/F(opening['quantity_change']);remaining=opening_cost-allocated
    proceeds=F(sale['trade_amount'])-F(sale['trade_fees']);require(remaining==1200 and proceeds==1790 and proceeds-allocated==590,'Identified proportional metal cost')
    grams={'g':F(1),'kg':F(1000),'troy_oz':F('31.1034768')}
    fine=F(lot['unit_weight'])*grams[lot['weight_unit']]*F(lot['purity'])
    quote=current(c,'metal_quotes')[0];require(F(quote['price'])==61,'Corrected quote')
    intrinsic=fine/grams[quote['weight_unit']]*F(quote['price'])
    require(fine==F('27.99312912') and intrinsic==F('1707.58087632'),'Fine weight and intrinsic value')
    first_quote=c.execute('SELECT cs.sequence FROM metal_quotes v JOIN revisions r ON r.id=v.revision_id JOIN change_sets cs ON cs.id=r.change_set_id ORDER BY cs.sequence LIMIT 1').fetchone()[0]
    oldquotes=current(c,'metal_quotes',first_quote);require(F(oldquotes[0]['price'])==60,'Historical quote')
    require(sum(F(m['quantity_change']) for m in current(c,'metal_movements',first_quote))==2,'Historical stock')
    storage=next(m for m in moves if m['kind']=='storage_transfer');require(storage['country']=='CH' and F(storage['quantity_change'])==0,'Storage transfer')
    rights=[r for r in current(c,'asset_ownerships') if r['asset_id']==lot['asset_id']]
    require(len(rights)==2 and sum(r['valid_to'] is None for r in rights)==1,'Closed and new metal rights')
    require(len({r['_change_set_id'] for r in rights})==1,'Atomic ownership batch')
    periods=current(c,'company_financial_periods');require(len(periods)==1 and F(periods[0]['revenue'])-F(periods[0]['operating_expenses'])==40000 and F(periods[0]['indicative_cash'])==999999,'Analytical observation')
    distributions=current(c,'company_distributions');paid=next(d for d in distributions if d['kind']=='paid');declared=next(d for d in distributions if d['kind']=='declared')
    require(F(paid['amount'])==300 and paid['related_declaration_id']==declared['object_id'],'Declared versus paid dividend')
    distribution_links=[dict(r) for r in c.execute('SELECT * FROM company_distribution_cash_links') if r['distribution_revision_id']==paid['revision_id']]
    require(len(distribution_links)==2 and sum(F(l['amount']) for l in distribution_links)==0,'Two sides of internal dividend')
    all_links=current(c,'cash_links')+current(c,'metal_cash_links')+distribution_links;used=defaultdict(F)
    for link in all_links:
        key=(link['transaction_revision_id'],link['line_id']);require(key in entries,'Link current revision/line')
        used[key]+=abs(F(link['amount']))
    require(all(total<=abs(F(entries[key]['amount'])) for key,total in used.items()),'Cross-module capacity')
    account_by_id={a['object_id']:a for a in accounts}
    source_tables={'rent_payment':'rent_payments','rental_expense':'rental_expenses','debt_movement':'debt_movements','deposit_movement':'deposit_movements'}
    for link in current(c,'cash_links'):
        source=next(s for s in current(c,source_tables[link['source_kind']]) if s['object_id']==link['source_id'])
        require(source['revision_id']==link['source_revision_id'],'Exact phase6 source revision')
        transaction=transactions[link['transaction_revision_id']];entry=entries[(link['transaction_revision_id'],link['line_id'])];account=account_by_id[entry['account_id']]
        require(transaction['effective_on']==source.get('paid_on',source['effective_on']),'Phase6 source date')
        if link['source_kind']=='debt_movement':
            contract=next(d for d in current(c,'debt_contracts') if d['object_id']==source['debt_id'])
            terms=next(t for t in current(c,'debt_terms') if t['debt_id']==source['debt_id'] and t['valid_from']<=source['effective_on'] and (t['valid_to'] is None or source['effective_on']<t['valid_to']))
            owners=[p['entity_id'] for p in c.execute('SELECT * FROM debt_parties WHERE terms_revision_id=? AND side=?',(terms['revision_id'],link['side']))]
            require(account['legal_owner_entity_id'] in owners and account['currency']==contract['currency'],'Loan cash owner/currency')
        else:
            require(account['legal_owner_entity_id']==source['recipient_entity_id'] and account['currency']==source['currency'],'Rental/deposit cash owner/currency')
    metal_link=current(c,'metal_cash_links')[0]
    require(metal_link['movement_revision_id']==sale['revision_id'] and metal_link['_change_set_id']==sale['_change_set_id']==transactions[metal_link['transaction_revision_id']]['_change_set_id'],'Atomic metal source and cash')
    metal_account=account_by_id[entries[(metal_link['transaction_revision_id'],metal_link['line_id'])]['account_id']]
    require(metal_link['movement_id']==sale['object_id'] and transactions[metal_link['transaction_revision_id']]['effective_on']==sale['effective_on'] and metal_account['legal_owner_entity_id']==sale['cash_entity_id'] and metal_account['currency']==sale['trade_currency'],'Metal source identity/date/currency/owner')
    require(all(transactions[l['transaction_revision_id']]['_change_set_id']==paid['_change_set_id'] for l in distribution_links),'Atomic dividend source and cash')
    for link in distribution_links:
        account=account_by_id[entries[(link['transaction_revision_id'],link['line_id'])]['account_id']]
        require(transactions[link['transaction_revision_id']]['effective_on']==paid['effective_on'] and account['currency']==paid['currency'],'Dividend date/currency')
        require(account['legal_owner_entity_id']==paid['company_id' if link['side']=='payer' else 'beneficiary_entity_id'] and F(link['amount'])==(-F(paid['amount']) if link['side']=='payer' else F(paid['amount'])),'Dividend owner and exact signed amount')
    known=F(350310)+named['TEST-B']+named['CO-TEST']+F('102.30')+outstanding+intrinsic
    require(known==F('355949.88087632'),'Known assets oracle')
    report_path=artifacts/'financial-restore-comparison.json'
    if report_path.exists():
        financial=json.loads(report_path.read_text())['after']
        require(financial['known_assets_eur']=='355949.88' and financial['known_liabilities_eur']=='100242.00' and financial['net_eur'] is None,'Financial report versus independent partial subtotals')
    require(not any(l['source_kind']=='rent_payment' for l in current(c,'cash_links')),'Unlinked rental sources must keep the net incomplete')
    rows={table:sorted(tuple(r) for r in c.execute(f'SELECT * FROM "{table}"')) for table in tables if table not in ['app_settings','change_sets','audit_events']}
    result={'archive':path.name,'status':'passed','schema':6,'sequence':manifest['mutation_sequence'],'manifested_files':len(manifest['files']),'table_count':len(tables),'objects':counts['objects'],'revisions':counts['revisions'],'foreign_key_violations':0,'integrity':'ok','migration_checksums':'all six match SQL','bank_balances':{k:str(v) for k,v in named.items()},'cash_tnd':str(balances[cash['object_id']]),'loan_principal_eur':'99000','deposit_obligation_eur':'1200','january_outstanding_eur':'700','metal_quantity':'1','fine_weight_g':str(fine),'intrinsic_eur':str(intrinsic),'metal_remaining_cost_eur':'1200','metal_realized_gain_eur':'590','actual_dividend_eur':'300','exact_cash_links':len(all_links),'known_assets_exact_eur':str(known),'known_net_exact_eur':str(known-F(100242))}
    return c,result,rows

primary,a,rows_a=inspect(artifacts/'desktop-backup.zip')
safety,b,rows_b=inspect(artifacts/'desktop-before-restore.zip')
require(rows_a==rows_b,'Business and child rows differ between backups')
with zipfile.ZipFile(root/'.local/desktop-smoke.yLQnPQrW/desktop-backup.zip') as z:
    old=sqlite3.connect(':memory:');old.deserialize(z.read('data/patrimoine.sqlite3'))
    require(old.execute('SELECT version,checksum FROM schema_migrations').fetchall()==[tuple(r) for r in primary.execute('SELECT version,checksum FROM schema_migrations WHERE version<=5')],'Historical SQL1-5 changed')
result={'status':'passed','method':'Python stdlib zipfile/hashlib/sqlite3/Fraction only; no application backend','archives':[a,b],'business_and_child_rows_identical':True,'historical_sql_1_to_5_unchanged':True}
(artifacts/'independent-backup-inspection.json').write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(result,ensure_ascii=False,indent=2))
