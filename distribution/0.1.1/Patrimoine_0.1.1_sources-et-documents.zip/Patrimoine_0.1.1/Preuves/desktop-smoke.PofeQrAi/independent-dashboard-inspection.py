#!/usr/bin/env python3
"""Independent checks of the synthetic native dashboard run (stdlib only).

The baseline financial report is compared with the report already saved during
the separate CSV round trip. Exact residual positions are recomputed here from
that report's original positions and internal eliminations, then annotated from
the source SQLite backup. This does not call the application or Rust helpers.

Historical observations are checked for civil dates, exact arithmetic, sources,
status and final-point reconciliation. Their complete financial engines are
not independently reimplemented by this inspection.
"""
from __future__ import annotations

import calendar
from collections import Counter, defaultdict
from datetime import date, timedelta
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3
import sys
import zipfile

ROOT = Path('/workspace/patrimoine')
ARTIFACTS = Path(sys.argv[1])


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'))


def ratio(value):
    require(isinstance(value, dict) and set(value) == {'num', 'den'}, 'Exact fraction shape')
    require(type(value['num']) is str and type(value['den']) is str, 'Fraction uses text integers')
    result = Fraction(int(value['num']), int(value['den']))
    require(value == {'num': str(result.numerator), 'den': str(result.denominator)}, 'Canonical reduced exact fraction')
    return result


def eur(value):
    # Independent integer half-even rounding, never binary floating point.
    scaled = abs(value) * 100
    cents, remainder = divmod(scaled.numerator, scaled.denominator)
    if 2 * remainder > scaled.denominator or 2 * remainder == scaled.denominator and cents % 2:
        cents += 1
    sign = '-' if value < 0 and cents else ''
    return f'{sign}{cents // 100}.{cents % 100:02}'


def applies(row, when):
    return row['valid_from'] <= when and (row['valid_to'] is None or when < row['valid_to'])


def current(connection, table, k):
    sql = f'''SELECT v.*,r.object_id AS _object_id,cs.sequence AS _sequence
        FROM "{table}" v JOIN revisions r ON r.id=v.revision_id JOIN change_sets cs ON cs.id=r.change_set_id
        WHERE cs.sequence<=? AND r.is_void=0 AND NOT EXISTS(
          SELECT 1 FROM revisions n JOIN change_sets ns ON ns.id=n.change_set_id
          WHERE n.object_id=r.object_id AND ns.sequence<=? AND ns.sequence>cs.sequence)'''
    return [dict(row) for row in connection.execute(sql, (k, k))]


def profiles(connection, k, when, periods, kind):
    table = 'entity_profiles' if kind == 'entity' else 'asset_profiles'
    result = {row['_object_id']: row for row in current(connection, table, k)}
    for period in periods:
        if period['target_kind'] == kind and applies(period, when):
            row = connection.execute(f'SELECT * FROM "{table}" WHERE revision_id=?', (period['profile_revision_id'],)).fetchone()
            require(row is not None, 'Exact dated descriptive revision')
            result[period['target_id']] = dict(row)
    return result


def source_metadata(connection, k, when):
    periods = current(connection, 'profile_periods', k)
    return {
        'entities': profiles(connection, k, when, periods, 'entity'),
        'assets': profiles(connection, k, when, periods, 'asset'),
        'properties': current(connection, 'property_details', k),
        'accounts': {row['_object_id']: row for row in current(connection, 'treasury_accounts', k)},
        'lots': {row['_object_id']: row for row in current(connection, 'metal_lots', k)},
        'ownerships': [row for row in current(connection, 'asset_ownerships', k) if applies(row, when)],
        'participations': [row for row in current(connection, 'company_participations', k) if applies(row, when)],
    }


def side(kind):
    if kind == 'guarantee':
        return 'contingent'
    if kind in ('overdraft', 'loan_debt', 'rent_debt', 'deposit_liability', 'advance_liability'):
        return 'liability'
    require(kind in ('asset', 'global_equity', 'metal', 'treasury', 'loan_receivable', 'rent_receivable', 'deposit_receivable', 'advance_receivable'), 'Known financial position side')
    return 'asset'


def classify(position, metadata, when):
    kind = position['kind']
    identifier = position['object_id']
    if kind == 'global_equity':
        return 'participations'
    if kind == 'metal':
        return 'or' if metadata['lots'][identifier]['metal'] == 'gold' else 'argent'
    if kind == 'treasury':
        return 'especes' if metadata['accounts'][identifier]['kind'] == 'cash' else 'banque'
    if kind == 'overdraft':
        return 'decouverts'
    if kind in ('loan_receivable', 'rent_receivable'):
        return 'creances'
    if kind in ('loan_debt', 'rent_debt'):
        return 'financements'
    if kind in ('deposit_receivable', 'deposit_liability'):
        return 'depots'
    if kind in ('advance_receivable', 'advance_liability'):
        return 'avances'
    if kind == 'asset' and (metadata['assets'].get(identifier, {}).get('category') in ('immobilier', 'real_estate') or any(p['asset_id'] == identifier and applies(p, when) for p in metadata['properties'])):
        return 'immobilier'
    return 'autres'


def expected_positions(financial, connection, k):
    when = financial['date']
    metadata = source_metadata(connection, k, when)
    results = []
    for original in financial['positions']:
        position = json.loads(json.dumps(original))
        identifier = position['object_id']
        account = metadata['accounts'].get(identifier)
        lot = metadata['lots'].get(identifier)
        asset_id = account['asset_id'] if account else lot['asset_id'] if lot else identifier
        asset = metadata['assets'].get(asset_id)
        owner_entity = metadata['entities'].get(position['entity_id'])
        country = position['country']
        if country is None:
            country = account['country'] if account else asset['country'] if asset else owner_entity['residence_country'] if owner_entity else None
        owners = {position['entity_id']} if position['entity_id'] is not None else set()
        owners.update(o['owner_entity_id'] for o in metadata['ownerships'] if o['asset_id'] == asset_id)
        if position['kind'] == 'global_equity':
            owners.update(p['owner_entity_id'] for p in metadata['participations'] if p['company_id'] == identifier)
        results.append({'position': position, 'side': side(position['kind']), 'category': classify(position, metadata, when), 'country': country,
                        'owner_entity_ids': sorted(owners), 'value': None if position['exact_eur'] is None else ratio(position['exact_eur']), 'eliminated': Fraction(0)})
    for elimination in financial['eliminations']:
        amount = ratio(elimination['exact_eliminated'])
        require(amount >= 0, 'Nonnegative internal elimination')
        for face in ('asset', 'liability'):
            selected = [row for row in results if row['position']['object_id'] == elimination['object_id'] and row['side'] == face and row['value'] is not None and row['value'] > 0]
            total = sum((row['value'] for row in selected), Fraction(0))
            require(total >= amount, 'Internal elimination bounded by original matching face')
            if amount == 0:
                continue
            for row in selected:
                reduction = amount * row['value'] / total
                row['value'] -= reduction
                row['eliminated'] += reduction
                row['position']['source_ids'] = sorted(set(row['position']['source_ids']) | set(elimination['source_ids']))
    for row in results:
        value = row.pop('value')
        eliminated = row.pop('eliminated')
        row.update(amount_eur=None if value is None else eur(value), exact_eur=None if value is None else {'num': str(value.numerator), 'den': str(value.denominator)},
                   eliminated_eur=eur(eliminated), exact_eliminated={'num': str(eliminated.numerator), 'den': str(eliminated.denominator)})
    return results


def same_rows(a, b, message):
    require(Counter(map(canonical, a)) == Counter(map(canonical, b)), message)


def check_totals(rows, total, financial=None):
    assets = sum((ratio(row['exact_eur']) for row in rows if row['side'] == 'asset' and row['exact_eur'] is not None), Fraction(0))
    liabilities = sum((ratio(row['exact_eur']) for row in rows if row['side'] == 'liability' and row['exact_eur'] is not None), Fraction(0))
    noncontingent = [row for row in rows if row['side'] != 'contingent']
    unknown = sum(row['exact_eur'] is None for row in noncontingent)
    for key, value in (('assets', assets), ('liabilities', liabilities), ('net', assets - liabilities)):
        require(ratio(total['exact_known_' + key]) == value and total['known_' + key + '_eur'] == eur(value), 'Dashboard exact subtotal and final rounding: ' + key)
    require(total['position_count'] == len(noncontingent) and total['unknown_count'] == unknown, 'Unknown and contingent counts')
    if financial is not None:
        for key, face in (('assets', 'asset'), ('liabilities', 'liability')):
            expected = eur(assets if key == 'assets' else liabilities) if financial[key + '_eur'] is not None and not any(row['exact_eur'] is None for row in rows if row['side'] == face) else None
            require(total[key + '_eur'] == expected, 'Coverage preserved for selected ' + key)
        require(total['net_eur'] == (eur(assets - liabilities) if financial['net_eur'] is not None and unknown == 0 else None), 'A filter cannot fabricate complete net coverage')
    return assets, liabilities


def check_groups(report):
    rows = report['positions']
    check_totals(rows, report['totals'], report['financial'])
    for name, dimension in (('by_category', 'category'), ('by_country', 'country'), ('by_currency', 'currency')):
        groups = defaultdict(list)
        for row in rows:
            if row['side'] != 'contingent':
                key = row['position']['currency'] if dimension == 'currency' else row[dimension] or 'unknown'
                groups[key].append(row)
        require(set(groups) == {bucket['key'] for bucket in report[name]}, 'Exact bucket inventory: ' + name)
        for bucket in report[name]:
            subset = groups[bucket['key']]
            amounts = check_totals(subset, {'exact_known_assets': bucket['exact_assets'], 'exact_known_liabilities': bucket['exact_liabilities'], 'exact_known_net': bucket['exact_net'],
                'known_assets_eur': bucket['known_assets_eur'], 'known_liabilities_eur': bucket['known_liabilities_eur'], 'known_net_eur': bucket['known_net_eur'],
                'position_count': bucket['position_count'], 'unknown_count': bucket['unknown_count']})
            require(all(v is not None for v in amounts), 'Grouped rational subtotals')


def civil_dates(request):
    start = date.fromisoformat(request['from_date'])
    end = date.fromisoformat(request['date'])
    output = [start]
    cursor = start
    while cursor < end:
        boundary = date(cursor.year, cursor.month, calendar.monthrange(cursor.year, cursor.month)[1]) if request['interval'] == 'monthly' else date(cursor.year, 12, 31)
        if boundary > cursor and boundary < end:
            output.append(boundary)
        if boundary >= end:
            break
        cursor = boundary + timedelta(days=1)
    if output[-1] != end:
        output.append(end)
    return [d.isoformat() for d in output]


def verify_history(report, source_values):
    points = report['history']
    require([p['date'] for p in points] == civil_dates(report['request']) and len(points) <= 61, 'Civil observation dates and fixed work budget')
    for point in points:
        t = point['totals']
        a, l = ratio(t['exact_known_assets']), ratio(t['exact_known_liabilities'])
        require(ratio(t['exact_known_net']) == a - l, 'Historical exact difference')
        require(t['known_assets_eur'] == eur(a) and t['known_liabilities_eur'] == eur(l) and t['known_net_eur'] == eur(a-l), 'Historical final rounding')
        require(t['net_eur'] is None if point['status'] != 'complete' else True, 'Unknown net chart point preserved')
        require(set(point['source_ids']) <= source_values, 'Historical trace exists in source knowledge')
    require(points[-1]['totals'] == report['totals'], 'Final chart point equals current selected subtotal')
    change = report['period_change']
    exact_change = ratio(points[-1]['totals']['exact_known_net']) - ratio(points[0]['totals']['exact_known_net'])
    require(change['from_date'] == points[0]['date'] and change['to_date'] == points[-1]['date'] and ratio(change['exact_known_net_change']) == exact_change and change['known_net_change_eur'] == eur(exact_change), 'Endpoint change is the exact difference, not a return')
    expected = None if any(p['totals']['net_eur'] is None for p in (points[0], points[-1])) else eur(exact_change)
    require(change['net_change_eur'] == expected, 'Unknown complete endpoint change preserved')


def main():
    native = json.loads((ARTIFACTS / 'desktop-result.json').read_text())
    require(native['status'] == 'passed' and len(native['steps']) >= 50 and all(step['status'] == 'passed' for step in native['steps']), 'Run the complete successful native campaign first')
    observed = json.loads((ARTIFACTS / 'dashboard-oracles.json').read_text())
    csv_reports = json.loads((ARTIFACTS / 'csv-roundtrip-reports.json').read_text())
    family, filtered, member, company = (observed[name] for name in ('family', 'filtered', 'member', 'company'))
    k = observed['source_sequence']
    require(k == csv_reports['source_sequence'] == 120 and observed['active_sequence'] == 121, 'Separate source/import knowledge contexts')
    with zipfile.ZipFile(ARTIFACTS / 'desktop-backup.zip') as archive:
        manifest = json.loads(archive.read('manifest.json'))
        require(manifest['schema_version'] == 6 and manifest['mutation_sequence'] == k and len(manifest['table_counts']) == 62, 'Source schema and full table catalogue')
        for record in manifest['files']:
            raw = archive.read(record['path'])
            require(len(raw) == record['size_bytes'] and digest(raw) == record['sha256'], 'Source manifested content')
        connection = sqlite3.connect(':memory:')
        connection.deserialize(archive.read('data/patrimoine.sqlite3'))
        connection.row_factory = sqlite3.Row
    connection.execute('PRAGMA trusted_schema=OFF')
    connection.execute('PRAGMA query_only=ON')
    require(connection.execute('PRAGMA integrity_check').fetchone()[0] == 'ok' and not connection.execute('PRAGMA foreign_key_check').fetchall(), 'Source SQLite integrity and foreign keys')
    table_names = [row[0] for row in connection.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
    require(len(table_names) == 62, 'All persistent source tables')
    source_values = set()
    for name in table_names:
        source_values.update(value for row in connection.execute(f'SELECT * FROM "{name}"') for value in row if isinstance(value, str))
    # Rental reciprocal positions have documented composite identities rather
    # than a separate persisted object: deposit/advance + lease + cash holder.
    # Resolve them from actual source records, never accept arbitrary prefixes.
    derived_identities = set()
    for table, prefix in (('deposit_movements', 'deposit'), ('rent_payments', 'advance')):
        for movement in current(connection, table, k):
            require(movement['lease_id'] in source_values and movement['recipient_entity_id'] in source_values, 'Derived rental identity references persisted sources')
            derived_identities.add(f"{prefix}-{movement['lease_id']}-{movement['recipient_entity_id']}")
    source_values.update(derived_identities)
    for version, checksum in connection.execute('SELECT version,checksum FROM schema_migrations ORDER BY version'):
        file = next((ROOT / 'crates/infrastructure/migrations').glob(f'{version:04}_*.sql'))
        require(digest(file.read_bytes()) == checksum, 'Unchanged historical migration')
    require(family['financial'] == csv_reports['reports']['financial'], 'Dashboard original financial report equals separate CSV source report including traces')
    require(family['totals']['known_assets_eur'] == '355949.88' and family['totals']['known_liabilities_eur'] == '100242.00' and family['totals']['net_eur'] is None, 'Golden known source subtotals remain explicitly incomplete')
    exact_rows = expected_positions(family['financial'], connection, k)
    same_rows(family['positions'], exact_rows, 'Independent exact residual positions and dated source metadata')
    check_groups(family)
    verify_history(family, source_values)
    for report in (family, filtered, member, company):
        require(report['knowledge_sequence'] == report['request']['knowledge_sequence'] == k and report['engine_version'] == 'dashboard-exact-1', 'Fixed context and dashboard engine version')
        require(set(report['source_ids']) <= source_values, 'Dashboard trace source exists in saved knowledge')
    same_rows(filtered['positions'], [r for r in exact_rows if r['category'] == 'or'], 'Gold filter selects already eliminated complete source positions')
    require(filtered['request']['filters']['category'] == 'or' and filtered['totals']['known_assets_eur'] == '1707.58' and filtered['totals']['net_eur'] is None, 'Exact gold value and incomplete coverage remain distinct')
    check_groups(filtered)
    verify_history(filtered, source_values)
    member_rows = expected_positions(member['financial'], connection, k)
    same_rows(member['positions'], member_rows, 'Individual residual positions reuse its exact source report')
    check_groups(member)
    verify_history(member, source_values)
    selected_member = next(row for row in family['members'] if row['entity_id'] == member['request']['entity_id'])
    require(selected_member['totals'] == member['totals'], 'Independent member view equals family member comparison')
    active_members = {r['person_id'] for r in current(connection, 'family_memberships', k) if applies(r, family['request']['date'])}
    require(active_members == {r['entity_id'] for r in family['members']}, 'No family member omitted from comparison')
    require(sum((ratio(row['totals']['exact_known_net']) for row in family['members']), Fraction(0)) == ratio(family['totals']['exact_known_net']), 'Synthetic member exact differences reconcile family difference, without adding gross amounts')
    require(company['totals'] is None and company['financial'] is None and company['history'] == [] and company['period_change'] is None, 'Company monitoring does not invent consolidated net')
    c = company['company']
    selected_periods = [row for row in current(connection, 'company_financial_periods', k) if row['company_id'] == c['company_id'] and company['request']['from_date'] < row['period_end'] <= company['request']['date']]
    expected_periods = []
    for row in selected_periods:
        expected_periods.append({**{key:value for key,value in row.items() if not key.startswith('_')}, 'id':row['_object_id']})
    same_rows([item['period'] for item in c['financial_periods']], expected_periods, 'Whole completed company observations preserve every source field and exact precision')
    require(any(p['revenue'] == '12345678901234567890.1234' for p in expected_periods), 'Long exact source decimal survives company monitoring')
    require({p['frequency'] for p in expected_periods} == {'annual','monthly'}, 'Parallel company frequencies remain separate')
    expected_distributions = [row for row in current(connection, 'company_distributions', k) if row['company_id'] == c['company_id'] and company['request']['from_date'] <= row['effective_on'] <= company['request']['date']]
    require({row['_object_id'] for row in expected_distributions} == {status['distribution']['id'] for status in c['distributions']}, 'Company distributions use the requested observed window')
    for name in ('family','filtered','member'):
        report = observed[name]
        for warning in report['warnings']:
            if warning['code'] == 'stale_valuation':
                possible = [row for row in current(connection, 'valuations', k) if row['revision_id'] in warning['message']]
                require(len(possible) == 1 and (date.fromisoformat(report['request']['date']) - date.fromisoformat(possible[0]['effective_on'])).days > 365, 'Old valuation warning references the exact source and strict threshold')
    envelope = json.loads((ARTIFACTS / 'dashboard-filtered-report.json').read_text())
    require(envelope['report_kind'] == 'patrimoine_filtered_report' and envelope['format_version'] == 1 and envelope['schema_version'] == 6, 'Filtered report export is a separate versioned consultation format')
    exported = json.loads(json.dumps(filtered))
    for section in ('financial','rental','variation'):
        exported[section] = None
    require(envelope['report'] == exported and set(envelope['excluded_sections']) == {'financial','rental','variation'}, 'Export excludes unfiltered monetary source sections and exactly matches the selected view')
    require(envelope['selection_note'] and envelope['purpose'], 'Export explains selection and consultation purpose')
    archive_proof = json.loads((ARTIFACTS / 'independent-phase8-inspection.json').read_text())
    xlsx_proof = json.loads((ARTIFACTS / 'independent-xlsx-inspection.json').read_text())
    require(archive_proof['status'] == xlsx_proof['status'] == 'passed', 'Independent portability reruns succeeded')
    result = {
        'status': 'passed', 'method': 'Python stdlib SQLite/ZIP/SHA-256/Fraction; no application backend or Rust helper',
        'source_sequence': k, 'active_sequence': observed['active_sequence'], 'native_steps_passed': len(native['steps']),
        'source_tables':len(table_names), 'source_rows':sum(manifest['table_counts'].values()),
        'family_original_report_equals_separate_csv_source_report':True,
        'residual_positions_recomputed_by_matching_object_and_face':len(exact_rows),
        'internal_eliminations_reallocated_exactly':len(family['financial']['eliminations']),
        'guarantees_excluded_from_totals':sum(row['side']=='contingent' for row in exact_rows),
        'category_country_currency_buckets_reconciled':True,
        'known_assets_eur':family['totals']['known_assets_eur'], 'known_liabilities_eur':family['totals']['known_liabilities_eur'],
        'complete_net_eur':None, 'gold_known_assets_eur':filtered['totals']['known_assets_eur'],
        'historical_points':len(family['history']), 'civil_dates_fixed_K_and_exact_endpoint_change':True,
        'historical_validation_limit':'Civil dates, exact subtotal arithmetic, recorded source references, status, endpoint change and final-point reconciliation checked; complete historical financial engines are not independently reimplemented here.',
        'family_members':len(family['members']), 'individual_source_projection_and_member_comparison_identical':True,
        'company_whole_periods':len(expected_periods), 'company_frequencies':sorted({p['frequency'] for p in expected_periods}),
        'company_long_decimal_exact':True, 'company_no_invented_net':True,
        'filtered_export_exact_view_and_no_unfiltered_monetary_sections':True,
        'all_source_references_resolve_to_persisted_or_documented_derived_identities':True,
        'derived_rental_identity_convention':'deposit/advance + persisted lease id + persisted recipient entity id',
        'derived_rental_identities':sorted(derived_identities), 'historical_migrations_1_to_6_unchanged':True,
        'portability_all_62_tables_and_originals_preserved':True,
        'xlsx_62_tables_before_and_after_actual_libreoffice_resave':True,
        'canonical_family_positions_sha256':digest(canonical(family['positions']).encode()),
        'canonical_filtered_report_sha256':digest(canonical(envelope).encode()),
    }
    output = ARTIFACTS / 'independent-dashboard-inspection.json'
    output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    shutil.copyfile(__file__, ARTIFACTS / 'independent-dashboard-inspection.py')
    print(json.dumps(result,ensure_ascii=False,indent=2))


if __name__ == '__main__':
    main()
