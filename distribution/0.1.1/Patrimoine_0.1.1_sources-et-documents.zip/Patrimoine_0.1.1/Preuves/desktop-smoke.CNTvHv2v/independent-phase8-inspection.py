#!/usr/bin/env python3
"""Read this synthetic phase-8 scenario using only standard Python libraries.

No application code, executable, DDL received from an archive or financial
helper is called. CSV values are decoded against the source SQLite schema.
"""
import csv
import hashlib
import io
import json
import re
import shutil
import sqlite3
import sys
import zipfile
from collections import Counter, defaultdict
from fractions import Fraction
from pathlib import Path

ROOT = Path('/workspace/patrimoine')
ARTIFACTS = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / '.local/desktop-smoke.sOCgGXI0'
INTEGER = re.compile(r'(?:0|-?[1-9][0-9]*)\Z')
csv.field_size_limit(1024 * 1024)


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def json_row(row):
    return json.dumps(list(row), ensure_ascii=False, separators=(',', ':'))


def canonical(rows):
    return sorted(json_row(row) for row in rows)


def tables(connection):
    return sorted(row[0] for row in connection.execute(
        "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"))


def records(connection):
    result = {}
    for table in tables(connection):
        rows = [tuple(row) for row in connection.execute(f'SELECT * FROM "{table}"')]
        require(all(value is None or type(value) in (int, str) for row in rows for value in row),
                'Unexpected storage class in ' + table)
        result[table] = canonical(rows)
    return result


def current(connection, table, cutoff=None):
    cutoff = cutoff if cutoff is not None else connection.execute('SELECT max(sequence) FROM change_sets').fetchone()[0]
    query = f'''SELECT v.*,r.object_id,r.change_set_id AS _change_set_id,cs.sequence AS _sequence
        FROM "{table}" v JOIN revisions r ON r.id=v.revision_id JOIN change_sets cs ON cs.id=r.change_set_id
        WHERE cs.sequence<=? AND r.is_void=0 AND NOT EXISTS(
          SELECT 1 FROM revisions n JOIN change_sets ns ON ns.id=n.change_set_id
          WHERE n.object_id=r.object_id AND ns.sequence<=? AND ns.sequence>cs.sequence)'''
    return [dict(row) for row in connection.execute(query, (cutoff, cutoff))]


def check_database(connection):
    connection.row_factory = sqlite3.Row
    require(connection.execute('PRAGMA user_version').fetchone()[0] == 6, 'SQLite schema differs')
    require(connection.execute('PRAGMA integrity_check').fetchone()[0] == 'ok', 'SQLite integrity')
    require(not connection.execute('PRAGMA foreign_key_check').fetchall(), 'SQLite foreign key violations')
    require(len(tables(connection)) == 62, 'Expected all 62 tables')
    migrations = list(connection.execute('SELECT version,checksum FROM schema_migrations ORDER BY version'))
    require(len(migrations) == 6, 'Six migration records are required')
    for version, checksum in migrations:
        sql = next((ROOT / 'crates/infrastructure/migrations').glob(f'{version:04d}_*.sql'))
        require(digest(sql.read_bytes()) == checksum, 'Migration fingerprint ' + str(version))
    return {table: connection.execute(f'SELECT count(*) FROM "{table}"').fetchone()[0]
            for table in tables(connection)}


def load_archive(name, kind):
    path = ARTIFACTS / name
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        require(len(names) == len(set(names)), 'Duplicate ZIP entry')
        require(archive.testzip() is None, 'ZIP CRC failure')
        manifest = json.loads(archive.read('manifest.json'))
        require(manifest['archive_kind'] == kind and manifest['format_version'] == 1
                and manifest['schema_version'] == 6, 'Unexpected archive version')
        require(manifest['calculation_policy_version'] == 'exact-rational-phase8-1', 'Calculation policy')
        declared = [entry['path'] for entry in manifest['files']]
        require(len(declared) == len(set(declared)), 'Duplicate manifest entry')
        require(set(names) == {'manifest.json'} | set(declared), 'Manifest file inventory')
        files = {}
        for entry in manifest['files']:
            data = archive.read(entry['path'])
            require(len(data) == entry['size_bytes'] and digest(data) == entry['sha256'], 'File hash/size: ' + entry['path'])
            files[entry['path']] = data
    manifest['_archive_sha256'] = digest(path.read_bytes())
    if kind == 'structured_csv':
        require('data/patrimoine.sqlite3' not in files, 'CSV must reconstruct tables rather than carry a database')
        return manifest, files, None, None
    connection = sqlite3.connect(':memory:')
    connection.deserialize(files['data/patrimoine.sqlite3'])
    counts = check_database(connection)
    require(counts == manifest['table_counts'], 'Manifest table counts')
    require(manifest['mutation_sequence'] == connection.execute('SELECT max(sequence) FROM change_sets').fetchone()[0], 'Knowledge sequence')
    require(manifest['document_count'] == counts['documents'] == 2, 'Logical document inventory')
    blobs = [dict(row) for row in connection.execute('SELECT * FROM document_blobs')]
    require(manifest['blob_count'] == len(blobs) == 2, 'Physical document inventory')
    for blob in blobs:
        expected = f"documents/sha256/{blob['sha256'][:2]}/{blob['sha256']}"
        require(blob['relative_path'] == expected, 'Content addressed path')
        require(len(files[expected]) == blob['size_bytes'] and digest(files[expected]) == blob['sha256'], 'Document original')
    return manifest, files, connection, records(connection)


def descriptor(connection, table):
    return [{'name': row['name'], 'declared_type': row['type'],
             'nullable': not bool(row['notnull']) and row['pk'] == 0,
             'primary_key': row['pk']}
            for row in connection.execute(f'PRAGMA table_info("{table}")')]


source_manifest, source_files, source, source_rows = load_archive('desktop-backup.zip', 'full_backup')
safety_manifest, safety_files, safety, safety_rows = load_archive('desktop-before-restore.zip', 'full_backup')
pre_csv_manifest, pre_csv_files, pre_csv, pre_csv_rows = load_archive('desktop-before-csv-import.zip', 'full_backup')
post_manifest, post_files, post, post_rows = load_archive('desktop-csv-roundtrip-backup.zip', 'full_backup')
csv_manifest, csv_files, _, _ = load_archive('desktop-export-csv.zip', 'structured_csv')
source_k = source_manifest['mutation_sequence']
require(pre_csv_rows == source_rows and pre_csv_manifest['mutation_sequence'] == source_k,
        'Binary restore and pre-CSV safety must reproduce all 62 tables')
require(csv_manifest['mutation_sequence'] == source_k and csv_manifest['table_counts'] == source_manifest['table_counts'],
        'CSV snapshot differs from binary snapshot')
require(csv_manifest['document_count'] == 2 and csv_manifest['blob_count'] == 2, 'CSV original inventory')

csv_descriptors = csv_manifest['tables']
require([table['name'] for table in csv_descriptors] == tables(source), 'Complete ordered CSV catalog')
decoded = {}
null_cells = empty_text_cells = integer_cells = 0
for table in csv_descriptors:
    name, columns = table['name'], table['columns']
    require(columns == descriptor(source, name), 'Approved source column descriptors: ' + name)
    data = csv_files['tables/' + name + '.csv']
    require(not data.startswith(b'\xef\xbb\xbf') and data.endswith(b'\r\n'), 'UTF-8/CRLF CSV dialect')
    rows = list(csv.reader(io.StringIO(data.decode('utf-8'), newline=''), strict=True))
    expected_header = [column['name'] for column in columns] + [column['name'] + '__is_null' for column in columns if column['nullable']]
    require(rows and rows[0] == expected_header, 'Exact CSV header: ' + name)
    result = []
    for row in rows[1:]:
        require(len(row) == len(expected_header), 'CSV width: ' + name)
        next_nullable = len(columns)
        values = []
        for index, column in enumerate(columns):
            is_null = False
            if column['nullable']:
                require(row[next_nullable] in ('0', '1'), 'Nullable marker')
                is_null = row[next_nullable] == '1'
                next_nullable += 1
            if is_null:
                require(row[index] == '', 'NULL requires an empty business cell')
                values.append(None)
                null_cells += 1
            elif column['declared_type'] == 'INTEGER':
                require(INTEGER.fullmatch(row[index]) is not None, 'Canonical integer')
                value = int(row[index])
                require(-(2**63) <= value < 2**63, 'Integer storage range')
                values.append(value)
                integer_cells += 1
            else:
                require(column['declared_type'] == 'TEXT', 'No numeric coercion for decimals')
                values.append(row[index])
                empty_text_cells += row[index] == ''
        result.append(tuple(values))
    require(len(result) == csv_manifest['table_counts'][name], 'CSV record count: ' + name)
    decoded[name] = canonical(result)
require(decoded == source_rows, 'CSV value/type reconstruction differs from SQLite source')
require(null_cells > 0 and empty_text_cells > 0 and integer_cells > 0, 'Fixture must exercise NULL, empty text and integers')


def added_rows(before, after, table):
    counts = Counter(after[table]) - Counter(before[table])
    require(not (Counter(before[table]) - Counter(after[table])), 'A source row was removed: ' + table)
    return [json.loads(row) for row, count in counts.items() for _ in range(count)]


for table in source_rows:
    if table not in ('app_settings', 'change_sets', 'audit_events'):
        require(safety_rows[table] == source_rows[table], 'Binary safety business rows: ' + table)
    if table not in ('change_sets', 'audit_events'):
        require(post_rows[table] == source_rows[table], 'CSV round-trip business rows: ' + table)
require(safety_manifest['mutation_sequence'] == source_k + 1, 'Binary safety adds one settings change')
require(len(added_rows(source_rows, safety_rows, 'change_sets')) == 1, 'Binary safety change count')
safety_audit = added_rows(source_rows, safety_rows, 'audit_events')
require(len(safety_audit) == 1 and safety_audit[0][4] == 'settings_updated', 'Binary safety audit')
source_settings = {row['key']: dict(row) for row in source.execute('SELECT * FROM app_settings')}
safety_settings = {row['key']: dict(row) for row in safety.execute('SELECT * FROM app_settings')}
require(source_settings.keys() == safety_settings.keys(), 'Settings keys')
require({key for key in source_settings if source_settings[key] != safety_settings[key]} == {'workspace_name', 'display_currency'}, 'Only settings modified before binary restore')
require(source_settings['display_currency']['value_text'] == 'CHF' and safety_settings['display_currency']['value_text'] == 'TND', 'Expected settings values')

changes = added_rows(source_rows, post_rows, 'change_sets')
audits = added_rows(source_rows, post_rows, 'audit_events')
require(len(changes) == len(audits) == 1 and post_manifest['mutation_sequence'] == source_k + 1, 'Single CSV technical provenance event')
change = dict(zip([r['name'] for r in post.execute('PRAGMA table_info(change_sets)')], changes[0]))
audit = dict(zip([r['name'] for r in post.execute('PRAGMA table_info(audit_events)')], audits[0]))
require(change['sequence'] == source_k + 1 and change['reason'] == 'Réimportation CSV intégrale', 'Technical change identity')
require(audit['change_set_id'] == change['id'] and audit['revision_id'] is None and audit['action'] == 'csv_imported', 'Technical audit linkage')
workspace = source_settings['workspace_id']['value_text']
require(audit['object_id'] == workspace, 'Existing workspace is the import provenance target')
require(csv_manifest['export_id'] in audit['summary'] and csv_manifest['_archive_sha256'] in audit['summary']
        and f'connaissances source {source_k}' in audit['summary'], 'Provenance must identify source export, hash and knowledge sequence')

blobs = [dict(row) for row in source.execute('SELECT * FROM document_blobs')]
for blob in blobs:
    path = blob['relative_path']
    require(source_files[path] == safety_files[path] == pre_csv_files[path] == post_files[path] == csv_files[path], 'Original bytes changed')
documents = current(source, 'document_versions')
require(len(documents) == 2 and sorted(document['status'] for document in documents) == ['active', 'deleted'], 'Document logical deletion')
document_history = [dict(row) for row in source.execute(
    "SELECT v.*,r.object_id,cs.sequence FROM document_versions v JOIN revisions r ON r.id=v.revision_id "
    "JOIN change_sets cs ON cs.id=r.change_set_id ORDER BY cs.sequence")]
require(len(document_history) == 6, 'All six document source versions retained')
active_document = next(document for document in documents if document['status'] == 'active')
deleted_document = next(document for document in documents if document['status'] == 'deleted')
active_history = [row for row in document_history if row['object_id'] == active_document['object_id']]
deleted_history = [row for row in document_history if row['object_id'] == deleted_document['object_id']]
require(len(active_history) == 4 and all(row['status'] == 'active' for row in active_history),
        'Metadata and replacement preserve the first logical document')
require([row['status'] for row in deleted_history] == ['active', 'deleted']
        and len({row['blob_sha256'] for row in deleted_history}) == 1,
        'Logical removal preserves the second document history and original')
require(active_history[0]['blob_sha256'] == active_history[1]['blob_sha256']
        and active_history[2]['blob_sha256'] == active_history[3]['blob_sha256']
        and active_history[0]['blob_sha256'] != active_history[2]['blob_sha256'],
        'Replacement keeps both original generations under one logical identity')
link_history = [dict(row) for row in source.execute(
    'SELECT v.*,r.object_id,r.is_void,cs.sequence FROM document_links v JOIN revisions r ON r.id=v.revision_id '
    'JOIN change_sets cs ON cs.id=r.change_set_id ORDER BY cs.sequence')]
require(len(link_history) == 3 and [row['role'] for row in link_history] == ['FAMILLE-TEST', 'METAL-TEST', 'FAMILLE-TEST']
        and [row['is_void'] for row in link_history] == [0, 0, 1],
        'Two associations retain their history after one explicit void')
current_document_links = current(source, 'document_links')
require(len(current_document_links) == 1 and current_document_links[0]['role'] == 'METAL-TEST'
        and current_document_links[0]['document_id'] == active_document['object_id'],
        'Removing one association preserves the other association and document')
old_documents = current(source, 'document_versions', active_history[0]['sequence'])
require(len(old_documents) == 1 and old_documents[0]['revision_id'] == active_history[0]['revision_id'],
        'First knowledge sequence still reconstructs the historical original')
shared = source.execute('''SELECT v.blob_sha256,count(DISTINCT r.object_id) FROM document_versions v
    JOIN revisions r ON r.id=v.revision_id GROUP BY v.blob_sha256 HAVING count(DISTINCT r.object_id)>1''').fetchall()
require(len(shared) == 1, 'Two logical documents initially shared one physical blob')
old_hash = shared[0][0]
require((ARTIFACTS / 'document-original-historique.txt').read_bytes() == source_files[f'documents/sha256/{old_hash[:2]}/{old_hash}'], 'Exported historical original bytes')
description = next(document['description'] for document in documents if document['status'] == 'active')
require(description.startswith('=HYPERLINK(') and '\r\n' in description and '\t' in description and '_x0000_' in description,
        'Verbatim formula-like and XML-escape-like document text')
revenue = [row[0] for row in source.execute('SELECT revenue FROM company_financial_periods')]
require('12345678901234567890.1234' in revenue, 'High precision decimal remains literal text')

transactions = {row['revision_id']: row for row in current(source, 'treasury_transactions')}
entries = {(row['transaction_revision_id'], row['line_id']): dict(row) for row in source.execute('SELECT * FROM treasury_entries')
           if row['transaction_revision_id'] in transactions}
accounts = {row['object_id']: row for row in current(source, 'treasury_accounts')}
ordinary_links = current(source, 'cash_links')
metal_links = current(source, 'metal_cash_links')
distributions = {row['revision_id']: row for row in current(source, 'company_distributions')}
distribution_links = [dict(row) for row in source.execute('SELECT * FROM company_distribution_cash_links') if row['distribution_revision_id'] in distributions]
all_links = ordinary_links + metal_links + distribution_links
require(len(all_links) == 8, 'All eight exact cash source links')
used = defaultdict(Fraction)
for link in all_links:
    key = (link['transaction_revision_id'], link['line_id'])
    require(key in entries, 'Current journal revision and line')
    used[key] += abs(Fraction(link['amount']))
require(all(value <= abs(Fraction(entries[key]['amount'])) for key, value in used.items()), 'Cross-module line capacity')
source_tables = {'rent_payment': 'rent_payments', 'rental_expense': 'rental_expenses', 'debt_movement': 'debt_movements', 'deposit_movement': 'deposit_movements'}
for link in ordinary_links:
    record = next(row for row in current(source, source_tables[link['source_kind']]) if row['object_id'] == link['source_id'])
    require(record['revision_id'] == link['source_revision_id'], 'Exact phase-6 source revision')
    account = accounts[entries[(link['transaction_revision_id'], link['line_id'])]['account_id']]
    require(transactions[link['transaction_revision_id']]['effective_on'] == (record['paid_on'] if 'paid_on' in record else record['effective_on']), 'Cash/source economic date')
    if link['source_kind'] == 'debt_movement':
        contract = next(row for row in current(source, 'debt_contracts') if row['object_id'] == record['debt_id'])
        terms = next(row for row in current(source, 'debt_terms') if row['debt_id'] == record['debt_id'] and row['valid_from'] <= record['effective_on'] and (row['valid_to'] is None or record['effective_on'] < row['valid_to']))
        parties = [row['entity_id'] for row in source.execute('SELECT * FROM debt_parties WHERE terms_revision_id=? AND side=?', (terms['revision_id'], link['side']))]
        require(account['legal_owner_entity_id'] in parties and account['currency'] == contract['currency'], 'Financing side owner and currency')
    else:
        require(account['legal_owner_entity_id'] == record['recipient_entity_id'] and account['currency'] == record['currency'], 'Deposit/rental owner and currency')
for link in metal_links:
    movement = next(row for row in current(source, 'metal_movements') if row['object_id'] == link['movement_id'])
    account = accounts[entries[(link['transaction_revision_id'], link['line_id'])]['account_id']]
    require(link['movement_revision_id'] == movement['revision_id'] and movement['_change_set_id'] == link['_change_set_id'] == transactions[link['transaction_revision_id']]['_change_set_id'], 'Atomic metal source/link/ledger')
    require(account['legal_owner_entity_id'] == movement['cash_entity_id'] and account['currency'] == movement['trade_currency'] and transactions[link['transaction_revision_id']]['effective_on'] == movement['effective_on'], 'Metal source owner, currency and date')
for link in distribution_links:
    distribution = distributions[link['distribution_revision_id']]
    account = accounts[entries[(link['transaction_revision_id'], link['line_id'])]['account_id']]
    require(distribution['_change_set_id'] == transactions[link['transaction_revision_id']]['_change_set_id'], 'Atomic dividend source and journal')
    require(account['legal_owner_entity_id'] == distribution['company_id' if link['side'] == 'payer' else 'beneficiary_entity_id']
            and account['currency'] == distribution['currency'] and transactions[link['transaction_revision_id']]['effective_on'] == distribution['effective_on'], 'Dividend owner, currency and date')
    require(Fraction(link['amount']) == (-Fraction(distribution['amount']) if link['side'] == 'payer' else Fraction(distribution['amount'])), 'Dividend exact signed sides')

with zipfile.ZipFile(ROOT / '.local/desktop-smoke.ku6m530N/desktop-backup.zip') as previous_archive:
    previous = sqlite3.connect(':memory:')
    previous.deserialize(previous_archive.read('data/patrimoine.sqlite3'))
    require(previous.execute('SELECT version,checksum FROM schema_migrations ORDER BY version').fetchall()
            == [tuple(row) for row in source.execute('SELECT version,checksum FROM schema_migrations ORDER BY version')], 'SQL 1-6 changed since phase 7')

cli_path = ARTIFACTS / 'csv-recovered.sqlite3'
require(cli_path.is_file(), 'Run the standalone CSV recovery before this inspection')
cli = sqlite3.connect('file:' + str(cli_path.resolve()) + '?mode=ro', uri=True)
check_database(cli)
require(records(cli) == source_rows, 'Standalone recovery differs from all 62 source tables')
cli_documents = ARTIFACTS / 'csv-recovered-documents'
expected_cli = set()
for blob in blobs:
    path = cli_documents / blob['relative_path'].removeprefix('documents/')
    expected_cli.add(path.relative_to(cli_documents).as_posix())
    require(path.read_bytes() == source_files[blob['relative_path']], 'Standalone recovered original')
require({path.relative_to(cli_documents).as_posix() for path in cli_documents.rglob('*') if path.is_file()} == expected_cli,
        'Standalone document directory inventory')
reports = json.loads((ARTIFACTS / 'csv-roundtrip-reports.json').read_text())
require(reports['source_sequence'] == source_k and reports['import_sequence'] == source_k + 1 and len(reports['reports']) == 9,
        'Native comparison report context')
require(all(report['knowledge_sequence'] == source_k for report in reports['reports'].values()), 'All nine financial reports use the preserved source K')

def archive_summary(name, manifest):
    return {'archive': name, 'sha256': manifest['_archive_sha256'], 'sequence': manifest['mutation_sequence'],
            'manifested_files': len(manifest['files']), 'tables': len(manifest['table_counts']),
            'objects': manifest['table_counts']['objects'], 'revisions': manifest['table_counts']['revisions'],
            'documents': manifest['document_count'], 'blobs': manifest['blob_count']}


result = {
    'status': 'passed',
    'method': 'Python standard library zipfile/hashlib/sqlite3/csv/Fraction; no application backend or archive SQL executed',
    'archives': [archive_summary(name, manifest) for name, manifest in [
        ('desktop-backup.zip', source_manifest), ('desktop-before-restore.zip', safety_manifest),
        ('desktop-before-csv-import.zip', pre_csv_manifest), ('desktop-csv-roundtrip-backup.zip', post_manifest),
        ('desktop-export-csv.zip', csv_manifest)]],
    'source_sequence': source_k, 'import_sequence': source_k + 1,
    'full_source_equals_csv_all_62_tables': True,
    'pre_csv_safety_equals_full_source_all_62_tables': True,
    'post_csv_business_history_and_originals_unchanged': True,
    'csv_provenance_extra_change_sets': len(changes), 'csv_provenance_extra_audit_events': len(audits),
    'csv_provenance_action': audit['action'], 'csv_provenance_existing_workspace': audit['object_id'] == workspace,
    'binary_safety_only_settings_change_and_audit': True,
    'standalone_csv_recovery_equals_source_all_62_tables': True,
    'standalone_recovered_originals_identical': True,
    'historical_sql_1_to_6_unchanged': True,
    'sqlite_integrity': 'ok', 'foreign_key_violations': 0,
    'null_cells_exact': null_cells, 'empty_text_cells_exact': empty_text_cells, 'integer_cells_exact': integer_cells,
    'high_precision_text': '12345678901234567890.1234',
    'literal_document_formula_crlf_tab_and_ooxml_escape_preserved': True,
    'logical_documents': len(documents), 'current_document_statuses': sorted(document['status'] for document in documents),
    'preserved_document_versions': len(document_history),
    'preserved_document_link_versions': len(link_history),
    'current_document_links': len(current_document_links),
    'document_replacement_logical_deletion_and_historical_K': True,
    'physical_originals': len(blobs), 'historical_shared_original_preserved': True,
    'exact_current_cash_links': len(all_links), 'cash_link_sources_dates_owners_currencies_and_shared_capacity': True,
    'native_comparison_reports_at_source_K': len(reports['reports']),
    'canonical_table_hashes': {table: digest(('\n'.join(rows)).encode('utf-8')) for table, rows in source_rows.items()},
}
output = ARTIFACTS / 'independent-phase8-inspection.json'
output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
shutil.copyfile(Path(__file__), ARTIFACTS / 'independent-phase8-inspection.py')
print(json.dumps({key: value for key, value in result.items() if key != 'canonical_table_hashes'}, ensure_ascii=False, indent=2))
