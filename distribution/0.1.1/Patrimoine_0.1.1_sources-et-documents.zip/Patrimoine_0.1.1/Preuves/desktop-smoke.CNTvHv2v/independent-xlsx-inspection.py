#!/usr/bin/env python3
"""Independent comparison of a synthetic native export with its SQLite snapshot.

Uses Python stdlib and openpyxl, then opens/saves with LibreOffice and repeats
the same comparison. No application backend or production export helper runs.
"""
import argparse
from collections import Counter, defaultdict
import hashlib
import json
import os
from pathlib import Path
import posixpath
import re
import shutil
import sqlite3
import subprocess
import tempfile
import xml.etree.ElementTree as ET
import zipfile

import openpyxl

MAIN = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PACKAGE_REL = "http://schemas.openxmlformats.org/package/2006/relationships"
ESCAPE = re.compile(r"_x([0-9A-Fa-f]{4})_")
MARKER = re.compile(r"^\[Texte long (TL[0-9]{8}) : fragments JSON dans les feuilles Textes longs\]$")
FALLBACK_KEY = re.compile(r"^ligne=([0-9]+);clé_sha256=([0-9a-f]{64})$")
PRECISION = "12345678901234567890.1234"


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def sha256(raw):
    return hashlib.sha256(raw).hexdigest()


def canonical(rows):
    encoded = sorted(json.dumps(list(row), ensure_ascii=True, separators=(",", ":")) for row in rows)
    return sha256(("\n".join(encoded) + "\n").encode())


def spreadsheet_text(text):
    """Decode SpreadsheetML escapes once, preserving protected literal motifs."""
    text = ESCAPE.sub(lambda match: chr(int(match[1], 16)), text)
    # SpreadsheetML may store supplementary characters as two UTF-16 escapes.
    return text.encode("utf-16-le", "surrogatepass").decode("utf-16-le")


def xml_text(node):
    if node is None:
        return ""
    # Only the displayed text runs; phonetic annotations are not cell values.
    parts = [n.text or "" for n in node.findall(f"{{{MAIN}}}t")]
    parts += [n.text or "" for n in node.findall(f"{{{MAIN}}}r/{{{MAIN}}}t")]
    return spreadsheet_text("".join(parts))


def column_index(address):
    letters = re.match(r"[A-Z]+", address).group()
    number = 0
    for letter in letters:
        number = number * 26 + ord(letter) - ord("A") + 1
    return number - 1


class Workbook:
    def __init__(self, path):
        self.path = Path(path)
        self.sheets = {}
        self.types = {}
        with zipfile.ZipFile(path) as archive:
            names = archive.namelist()
            require(len(names) == len(set(names)), "Duplicate OOXML entries")
            require(archive.testzip() is None, "Corrupt workbook ZIP")
            for name in names:
                lowered = name.lower()
                require("externallinks" not in lowered and not lowered.endswith(".bin"), "Active external or macro package part")
                if name.endswith(".rels"):
                    relationships = ET.fromstring(archive.read(name))
                    require(all(r.attrib.get("TargetMode", "").lower() != "external" for r in relationships), "External relationship")
            strings = []
            if "xl/sharedStrings.xml" in names:
                strings = [xml_text(n) for n in ET.fromstring(archive.read("xl/sharedStrings.xml")).findall(f"{{{MAIN}}}si")]
            relationships = {
                r.attrib["Id"]: r.attrib["Target"]
                for r in ET.fromstring(archive.read("xl/_rels/workbook.xml.rels"))
            }
            workbook = ET.fromstring(archive.read("xl/workbook.xml"))
            for sheet in workbook.findall(f"{{{MAIN}}}sheets/{{{MAIN}}}sheet"):
                name = sheet.attrib["name"]
                require(len(name.encode("utf-16-le")) // 2 <= 31, "Sheet name exceeds Excel limit")
                require(name not in self.sheets, "Duplicate sheet name")
                target = relationships[sheet.attrib[f"{{{REL}}}id"]]
                target = target.lstrip("/") if target.startswith("/") else posixpath.normpath("xl/" + target)
                require(not target.startswith("../"), "Escaping OOXML relationship")
                root = ET.fromstring(archive.read(target))
                require(root.find(f"{{{MAIN}}}hyperlinks") is None, "Active worksheet hyperlink")
                require(not any(n.tag == f"{{{MAIN}}}f" for n in root.iter()), "Formula cell")
                rows = []
                cell_types = {}
                for row in root.findall(f"{{{MAIN}}}sheetData/{{{MAIN}}}row"):
                    number = int(row.attrib["r"])
                    require(number <= 1_048_576, "Sheet exceeds Excel row limit")
                    values = []
                    for cell in row.findall(f"{{{MAIN}}}c"):
                        address = cell.attrib["r"]
                        column = column_index(address)
                        require(column < 16_384, "Sheet exceeds Excel column limit")
                        kind = cell.attrib.get("t", "n")
                        value_node = cell.find(f"{{{MAIN}}}v")
                        if kind == "inlineStr":
                            value = xml_text(cell.find(f"{{{MAIN}}}is"))
                        elif kind == "s":
                            value = strings[int(value_node.text)]
                        elif kind == "str":
                            value = spreadsheet_text(value_node.text or "") if value_node is not None else ""
                        elif value_node is None or value_node.text is None:
                            value = ""
                        else:
                            raise AssertionError(f"Nontext value in {name}:{address} ({kind})")
                        require(len(value.encode("utf-16-le")) // 2 <= 32_767, "Decoded cell exceeds UTF-16 limit")
                        if len(values) <= column:
                            values.extend([""] * (column + 1 - len(values)))
                        values[column] = value
                        cell_types[address] = kind
                    rows.append((number, values))
                # Empty formatting rows are not data; source tables have keys.
                while rows and not any(rows[-1][1]):
                    rows.pop()
                self.sheets[name] = rows
                self.types[name] = cell_types
        require("Informations" in self.sheets and "Dictionnaire" in self.sheets, "Missing workbook notices/dictionary")
        self.mapping = defaultdict(list)
        self.dictionary = []
        for name, rows in self.sheets.items():
            if name == "Dictionnaire" or re.fullmatch(r"Dictionnaire [0-9]+", name):
                require(rows and rows[0][1][:3] == ["Feuille", "Table", "Colonne"], "Dictionary headers")
                self.dictionary.extend(values for _, values in rows[1:])
        for row in self.dictionary:
            require(len(row) >= 8, "Incomplete dictionary record")
            if row[0] not in self.mapping[row[1]]:
                self.mapping[row[1]].append(row[0])
        self.fragments = defaultdict(list)
        for name, rows in self.sheets.items():
            if name == "Textes longs" or re.fullmatch(r"Textes longs [0-9]+", name):
                require(rows and rows[0][1][:5] == ["Référence", "Table", "Clé primaire", "Colonne", "Fragment"], "Long-text headers")
                for _, values in rows[1:]:
                    require(len(values) == 7 and values[5] == "JSON chaîne UTF-8", "Long-text encoding")
                    key = tuple(values[:4])
                    decoded = json.loads(values[6])
                    require(isinstance(decoded, str), "Long-text fragment must be one JSON string")
                    self.fragments[key].append((int(values[4]), decoded))
        for key, fragments in self.fragments.items():
            indices = sorted(n for n, _ in fragments)
            require(indices == list(range(1, len(indices) + 1)), "Missing/duplicate long-text fragments")
        self.openpyxl_escape_normalizations = self.verify_openpyxl()

    def verify_openpyxl(self):
        workbook = openpyxl.load_workbook(self.path, read_only=False, data_only=False, keep_links=True)
        require(workbook.sheetnames == list(self.sheets), "openpyxl sheet catalogue differs")
        observations = 0
        try:
            for name, rows in self.sheets.items():
                worksheet = workbook[name]
                for number, values in rows:
                    for column, expected in enumerate(values, 1):
                        cell = worksheet.cell(number, column)
                        require(cell.data_type != "f" and cell.hyperlink is None, "openpyxl active cell")
                        actual = "" if cell.value is None else cell.value
                        require(isinstance(actual, str), "openpyxl converted exact text to a nontext type")
                        if actual != expected:
                            # openpyxl 3.1.5 differs for inline/shared OOXML escapes.
                            # Read the package once semantically, never decode a
                            # literal-looking already-decoded value a second time.
                            compatible_escape = spreadsheet_text(actual) == expected
                            known_shared_string_loss = actual == expected.replace("x005F_", "")
                            require(compatible_escape or known_shared_string_loss, f"openpyxl data mismatch in {name}:{cell.coordinate}")
                            observations += 1
        finally:
            workbook.close()
        return observations

    def table(self, name, columns):
        headers = []
        for _, column, _, notnull, _, primary in columns:
            headers.append(column)
            if not notnull and not primary:
                headers.append(column + "__is_null")
        names = self.mapping[name]
        require(names, f"Missing source table sheet {name}")
        # Workbook order, rather than alphabetical suffix order, preserves
        # source row ordinals used by the rare long-primary-key fallback.
        names = [sheet for sheet in self.sheets if sheet in names]
        raw_rows = []
        for sheet in names:
            rows = self.sheets[sheet]
            require(rows and rows[0][1] == headers, f"Source headers differ for {name}")
            for _, row in rows[1:]:
                require(len(row) <= len(headers), f"Extra cells in {name}")
                raw_rows.append(row + [""] * (len(headers) - len(row)))
        primary_columns = [column for _, column, _, _, _, pk in columns if pk]
        decoded_rows = []
        used_fragments = set()
        for row_number, row in enumerate(raw_rows, 1):
            values = dict(zip(headers, row))
            visible_key = json.dumps({col: values[col] for col in primary_columns}, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
            resolved = {}
            resolved_contexts = []
            for _, column, kind, notnull, _, primary in columns:
                value = values[column]
                marker = MARKER.fullmatch(value)
                if marker:
                    candidates = [(key, pieces) for key, pieces in self.fragments.items()
                                  if key[0] == marker[1] and key[1] == name and key[3] == column
                                  and (key[2] == visible_key or (FALLBACK_KEY.fullmatch(key[2]) and int(FALLBACK_KEY.fullmatch(key[2])[1]) == row_number))]
                    if candidates:
                        require(len(candidates) == 1, "Ambiguous long-text context")
                        key, pieces = candidates[0]
                        value = "".join(text for _, text in sorted(pieces))
                        resolved_contexts.append(key)
                        used_fragments.add(key)
                if not notnull and not primary:
                    flag = values[column + "__is_null"]
                    require(flag in ("0", "1"), f"Invalid NULL marker {name}.{column}")
                    if flag == "1":
                        require(value == "", f"NULL with a nonempty payload {name}.{column}")
                        resolved[column] = None
                        continue
                if kind == "INTEGER":
                    number = int(value)
                    require(str(number) == value, f"Noncanonical integer {name}.{column}")
                    resolved[column] = number
                else:
                    require(kind == "TEXT", f"Unsupported source type {name}.{column}")
                    resolved[column] = value
            original_key = json.dumps({col: None if resolved[col] is None else str(resolved[col]) for col in primary_columns}, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
            for key in resolved_contexts:
                fallback = FALLBACK_KEY.fullmatch(key[2])
                if fallback:
                    require(int(fallback[1]) == row_number and fallback[2] == sha256(original_key.encode()), "Long primary-key hash/ordinal mismatch")
                else:
                    require(key[2] == original_key, "Long-text primary-key context mismatch")
            decoded_rows.append(tuple(resolved[col] for _, col, *_ in columns))
        return decoded_rows, used_fragments


def source_database(path):
    with zipfile.ZipFile(path) as archive:
        require(archive.testzip() is None, "Corrupt source backup")
        manifest = json.loads(archive.read("manifest.json"))
        require(manifest["schema_version"] == 6 and manifest["format_version"] == 1, "Unexpected source schema/format")
        for entry in manifest["files"]:
            raw = archive.read(entry["path"])
            require(len(raw) == entry["size_bytes"] and sha256(raw) == entry["sha256"], "Source backup hash/size mismatch")
        c = sqlite3.connect(":memory:")
        c.deserialize(archive.read("data/patrimoine.sqlite3"))
    c.execute("PRAGMA trusted_schema=OFF")
    c.execute("PRAGMA query_only=ON")
    require(c.execute("PRAGMA integrity_check").fetchone()[0] == "ok", "Source SQLite integrity")
    require(not c.execute("PRAGMA foreign_key_check").fetchall(), "Source SQLite foreign keys")
    return c, manifest


def compare(path, database, manifest):
    book = Workbook(path)
    names = [r[0] for r in database.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")]
    require(len(names) == 62, "Source does not contain the complete schema-6 catalogue")
    source_counts = {name: database.execute(f'SELECT count(*) FROM "{name}"').fetchone()[0] for name in names}
    require(source_counts == manifest["table_counts"], "Source manifest table counts")
    information = {values[0]: values[1] for _, values in book.sheets["Informations"][1:] if len(values) >= 2}
    require(information["Connaissances"] == str(manifest["mutation_sequence"]), "Workbook and ZIP snapshot knowledge differ")
    require(information["Schéma SQLite"] == "6" and information["Tables sources"] == "62", "Workbook source catalogue metadata")
    used_fragments = set()
    tables = []
    adversarial = {"formula_like_texts": 0, "literal_ooxml_texts": 0, "crlf_texts": 0, "high_precision_texts": 0, "empty_strings": 0, "null_values": 0}
    for name in names:
        columns = database.execute(f'PRAGMA table_info("{name}")').fetchall()
        source = [tuple(r) for r in database.execute(f'SELECT * FROM "{name}"')]
        exported, fragments = book.table(name, columns)
        require(Counter(source) == Counter(exported), f"Canonical row/value mismatch in {name}")
        require(canonical(source) == canonical(exported), f"Canonical table hash mismatch in {name}")
        used_fragments.update(fragments)
        for row in source:
            for value in row:
                adversarial["null_values"] += value is None
                if isinstance(value, str):
                    adversarial["empty_strings"] += value == ""
                    adversarial["formula_like_texts"] += value.startswith(("=", "+", "-", "@"))
                    adversarial["literal_ooxml_texts"] += "_x0000_" in value or "_x000A_" in value
                    adversarial["crlf_texts"] += "\r\n" in value
                    adversarial["high_precision_texts"] += PRECISION in value
        tables.append({"table": name, "rows": len(source), "columns": len(columns), "sheets": book.mapping[name], "canonical_sha256": canonical(source)})
    require(all(adversarial.values()), "Synthetic dataset does not exercise every required adversarial value class")
    # A fragment may belong to a documented read-only view/notice; those are
    # intentionally outside the canonical source table catalogue.
    orphaned = [key for key in book.fragments if key[1] in names and key not in used_fragments]
    require(not orphaned, "Unresolved canonical source long-text fragments")
    return {"status": "passed", "workbook": Path(path).name, "reader": "Python stdlib XML/ZIP with one-pass SpreadsheetML decoding + openpyxl " + openpyxl.__version__, "openpyxl_reader_limit": "openpyxl 3.1.5 does not consistently decode inline/shared SpreadsheetML escapes and its shared-string reader removes x005F_ substrings; canonical values below come from strict independent XML decoding, not this lossy library transformation", "source_knowledge_sequence": manifest["mutation_sequence"], "source_tables": len(names), "source_rows": sum(source_counts.values()), "worksheets": len(book.sheets), "reconstructed_long_text_values": len(used_fragments), "formula_cells": 0, "macro_parts": 0, "active_hyperlinks": 0, "external_relationships": 0, "openpyxl_escape_normalizations": book.openpyxl_escape_normalizations, "adversarial_source_values": adversarial, "tables": tables}


def libreoffice_roundtrip(source, output_directory):
    executable = shutil.which("soffice") or shutil.which("libreoffice")
    require(executable is not None, "LibreOffice unavailable")
    output_directory.mkdir(mode=0o700, parents=True, exist_ok=True)
    output = output_directory / source.name
    require(output.resolve() != source.resolve(), "LibreOffice output would overwrite the source export")
    if output.exists():
        output.unlink()
    with tempfile.TemporaryDirectory(prefix="patrimoine-phase8-lo-", dir="/tmp") as profile:
        profile_arg = "-env:UserInstallation=" + Path(profile).as_uri()
        version = subprocess.run([executable, profile_arg, "--headless", "--version"], capture_output=True, text=True, timeout=20, check=True)
        completed = subprocess.run([executable, profile_arg, "--headless", "--convert-to", "xlsx:Calc MS Excel 2007 XML", "--outdir", str(output_directory.resolve()), str(source.resolve())], capture_output=True, text=True, timeout=60, env={**os.environ, "SAL_USE_VCLPLUGIN": "svp"})
    require(completed.returncode == 0 and output.is_file(), "LibreOffice could not open and resave the workbook")
    output.chmod(0o600)
    return output, {"version": version.stdout.strip(), "exit_code": completed.returncode, "filter": "Calc MS Excel 2007 XML", "output": str(output.relative_to(output_directory.parent)), "source_sha256_preserved": sha256(source.read_bytes())}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("artifacts", type=Path)
    parser.add_argument("--skip-libreoffice", action="store_true")
    args = parser.parse_args()
    source = args.artifacts / "desktop-export.xlsx"
    original_hash = sha256(source.read_bytes())
    database, manifest = source_database(args.artifacts / "desktop-backup.zip")
    result = {"status": "passed", "method": "No application backend; compare every original SQLite row/type with decoded workbook source tables", "original": compare(source, database, manifest)}
    if not args.skip_libreoffice:
        reread, command = libreoffice_roundtrip(source, args.artifacts / "libreoffice-resaved")
        result["libreoffice"] = command
        result["libreoffice_resaved"] = compare(reread, database, manifest)
        require(sha256(source.read_bytes()) == original_hash, "LibreOffice modified the source export")
    destination = args.artifacts / "independent-xlsx-inspection.json"
    destination.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    shutil.copyfile(__file__, args.artifacts / "independent-xlsx-inspection.py")
    summary = {"status": result["status"], "source_tables": result["original"]["source_tables"], "source_rows": result["original"]["source_rows"], "original_canonical_values": "identical", "libreoffice": result.get("libreoffice"), "resaved_canonical_values": "identical" if "libreoffice_resaved" in result else "not requested", "report": str(destination)}
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
