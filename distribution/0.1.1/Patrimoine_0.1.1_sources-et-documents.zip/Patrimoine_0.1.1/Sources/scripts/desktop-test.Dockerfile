# syntax=docker/dockerfile:1
# Environnement de validation uniquement, pas un mode de déploiement du produit.
FROM debian:13-slim@sha256:f6b08b09a05725f9431502d3b5714f5c4576e82c1a84fa1debe0c24a7e0c3ec4
RUN --mount=type=secret,id=system_ca,required=true,mode=0444 \
    sed -i 's|http://deb.debian.org|https://deb.debian.org|g' /etc/apt/sources.list.d/debian.sources \
    && apt-get -o Acquire::https::CaInfo=/run/secrets/system_ca update \
    && apt-get -o Acquire::https::CaInfo=/run/secrets/system_ca install -y --no-install-recommends \
        libwebkit2gtk-4.1-0 libgtk-3-0t64 webkit2gtk-driver xvfb xauth dbus-x11 \
        python3 xdotool fonts-dejavu-core \
    && rm -rf /var/lib/apt/lists/* \
    && useradd --uid 1000 --create-home patrimoine
USER 1000:1000
ENV LANG=C.UTF-8
WORKDIR /app
